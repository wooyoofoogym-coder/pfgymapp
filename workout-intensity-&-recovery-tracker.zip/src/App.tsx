import React, { useState, useEffect } from 'react';
import { ActiveTab, CustomGoals, SpaSession, WorkoutSession } from './types';
import {
  deleteWorkoutSession,
  getCustomGoals,
  getHydrationToday,
  getSpaHistory,
  getWorkoutsHistory,
  saveCustomGoals,
  saveHydrationToday,
  saveSpaSession,
  saveWorkoutSession,
} from './utils/storage';
import { Navigation } from './components/Navigation';
import { ActiveGymWorkout } from './components/ActiveGymWorkout';
import { SpaProtocol } from './components/SpaProtocol';
import { IntensityAnalytics } from './components/IntensityAnalytics';
import { CustomGoalsView } from './components/CustomGoalsView';
import { MusicPlayerDock } from './components/MusicPlayerDock';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('workout');
  const [customGoals, setCustomGoals] = useState<CustomGoals>(getCustomGoals());
  const [workouts, setWorkouts] = useState<WorkoutSession[]>(getWorkoutsHistory());
  const [spaSessions, setSpaSessions] = useState<SpaSession[]>(getSpaHistory());
  const [hydration, setHydration] = useState<{ date: string; ounces: number }>(getHydrationToday());
  const [isMusicOpen, setIsMusicOpen] = useState<boolean>(false);
  const [musicCategory, setMusicCategory] = useState<'cardio' | 'strength' | 'recovery' | 'focus' | undefined>(undefined);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem('pf_theme');
      return saved === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('pf_theme', theme);
    } catch {
      // ignore
    }
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  useEffect(() => {
    saveHydrationToday(hydration.ounces);
  }, [hydration.ounces]);

  const handleTriggerMusic = (category: 'cardio' | 'strength' | 'recovery' | 'focus') => {
    setMusicCategory(category);
    setIsMusicOpen(true);
  };

  const handleSaveGoals = (newGoals: CustomGoals) => {
    setCustomGoals(newGoals);
    saveCustomGoals(newGoals);
  };

  const handleSaveWorkout = (session: WorkoutSession) => {
    const updated = saveWorkoutSession(session);
    setWorkouts(updated);
  };

  const handleDeleteWorkout = (id: string) => {
    const updated = deleteWorkoutSession(id);
    setWorkouts(updated);
  };

  const handleSaveSpaSession = (session: SpaSession) => {
    const updated = saveSpaSession(session);
    setSpaSessions(updated);
  };

  const handleAddHydration = (oz: number) => {
    setHydration((prev) => ({
      ...prev,
      ounces: Math.min(prev.ounces + oz, customGoals.dailyHydrationOzTarget * 2),
    }));
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0c0714] text-[#f5effa]' : 'bg-[#fbf9fd] text-slate-900'} font-sans flex flex-col antialiased selection:bg-pf-yellow selection:text-pf-purple-deep pb-16 transition-colors duration-200`}>
      {/* App Header & Navigation */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        hydrationOunces={hydration.ounces}
        hydrationTarget={customGoals.dailyHydrationOzTarget}
        onAddHydration={handleAddHydration}
        onToggleMusic={() => setIsMusicOpen((prev) => !prev)}
        isMusicOpen={isMusicOpen}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'workout' && (
          <ActiveGymWorkout
            customGoals={customGoals}
            pastWorkouts={workouts}
            onSaveWorkout={handleSaveWorkout}
            onNavigateToAnalytics={() => setActiveTab('analytics')}
            onUpdateGoals={handleSaveGoals}
            onTriggerMusic={handleTriggerMusic}
          />
        )}

        {activeTab === 'recovery' && (
          <SpaProtocol
            onSaveSpaSession={handleSaveSpaSession}
            onNavigateToAnalytics={() => setActiveTab('analytics')}
            onTriggerMusic={handleTriggerMusic}
          />
        )}

        {activeTab === 'analytics' && (
          <IntensityAnalytics
            workouts={workouts}
            spaSessions={spaSessions}
            customGoals={customGoals}
            onDeleteWorkout={handleDeleteWorkout}
          />
        )}

        {activeTab === 'goals' && (
          <CustomGoalsView
            goals={customGoals}
            onSaveGoals={handleSaveGoals}
          />
        )}
      </main>

      {/* Persistent Music Player Dock (Spotify & YouTube Music with interactive controls) */}
      <MusicPlayerDock
        isOpen={isMusicOpen}
        onToggleOpen={() => setIsMusicOpen((prev) => !prev)}
        suggestedCategory={musicCategory}
      />

      {/* Footer with Planet Fitness Judgement Free Signature */}
      <footer className={`border-t ${theme === 'dark' ? 'border-[#2f1a45] bg-[#12091c] text-[#a69ab4]' : 'border-pf-purple-border/60 bg-white text-slate-500'} py-6 text-center text-xs mt-8 transition-colors`}>
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className={`font-extrabold ${theme === 'dark' ? 'text-white' : 'text-pf-purple-deep'}`}>Planet Fitness Routine Tracker</span>
            <span className="text-pf-purple">•</span>
            <span className="font-bold text-pf-yellow">Judgement Free Zone®</span>
            <span className="text-pf-purple">•</span>
            <span>Active Gym Days & Black Card® Spa Splits</span>
          </div>
          <p className={theme === 'dark' ? 'text-[#87789c]' : 'text-slate-400'}>
            Engineered for steady intensity progression, structured rest windows, and personalized milestones.
          </p>
        </div>
      </footer>
    </div>
  );
}
