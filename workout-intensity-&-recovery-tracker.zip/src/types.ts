export type ProgressionTier = 'weeks_1_2' | 'weeks_3_4' | 'weeks_5_6_plus' | 'custom';

export type ActiveTab = 'workout' | 'recovery' | 'analytics' | 'goals';

export interface SetLog {
  id: string;
  setNumber: number;
  targetReps: string;
  actualReps: number;
  weightLbs: number;
  rpe: number; // 1-10
  completed: boolean;
  restDurationSeconds: number;
}

export interface ExerciseDefinition {
  id: string;
  name: string;
  defaultSets: number;
  defaultReps: string;
  keyFocus: string;
  suggestedRestSeconds: number;
  defaultWeight: number;
}

export interface ExerciseSessionLog {
  exerciseId: string;
  name: string;
  keyFocus: string;
  sets: SetLog[];
}

export interface CardioSessionLog {
  inclinePercent: number;
  speedMph: number;
  targetDurationMinutes: number;
  actualDurationMinutes: number;
  targetRpe: string;
  actualRpe: number;
  coolDownCompleted: boolean;
  notes: string;
}

export interface ReadinessCheck {
  sleepQuality: number; // 1-5
  energyLevel: number; // 1-5
  muscleSoreness: number; // 1-5 (1 = none, 5 = severe)
  readinessScore: number; // 0-100
  status: 'optimal' | 'moderate' | 'fatigued';
  recommendedRestSeconds: number;
  date: string;
}

export interface ProgressiveOverloadSuggestion {
  exerciseId: string;
  exerciseName: string;
  currentWeightLbs: number;
  suggestedWeightLbs: number;
  increaseLbs: number;
  reason: string;
}

export interface TreadmillOverloadSuggestion {
  currentTier: ProgressionTier;
  suggestedTier: ProgressionTier;
  suggestedIncline: number;
  suggestedSpeed: number;
  reason: string;
}

export interface WorkoutSession {
  id: string;
  date: string; // ISO string
  totalDurationMinutes: number;
  preWorkoutPrepMinutes: number;
  prepCompleted: boolean;
  prepLevel: number;
  cardio: CardioSessionLog;
  exercises: ExerciseSessionLog[];
  postWorkoutHydroMinutes: number;
  postWorkoutCompleted: boolean;
  totalRestRecoverySeconds: number;
  averageRpe: number;
  totalVolumeLbs?: number; // Weight x Reps summed across completed sets
  readiness?: ReadinessCheck;
  notes: string;
}

export interface SpaAmenity {
  id: string;
  order: number;
  name: string;
  defaultMinutes: number;
  purpose: string;
  actionRule: string;
  completed: boolean;
  actualMinutes: number;
}

export interface SpaSession {
  id: string;
  date: string;
  amenities: {
    amenityId: string;
    name: string;
    durationMinutes: number;
    completed: boolean;
  }[];
  totalDurationMinutes: number;
  sorenessBefore?: number; // 1-5
  sorenessAfter?: number; // 1-5
  targetMuscleGroup?: string;
  notes: string;
}

export interface CustomGoals {
  progressionTier: ProgressionTier;
  customCardioIncline: number;
  customCardioSpeed: number;
  customCardioMinutes: number;
  targetMinRpe: number;
  targetMaxRpe: number;
  defaultRestTimerSeconds: number;
  weeklyGymDaysTarget: number;
  weeklySpaDaysTarget: number;
  dailyHydrationOzTarget: number;
  exerciseTargets: Record<string, { targetWeightLbs: number; targetReps: number; targetSets: number }>;
}

export interface RpeGuideLevel {
  level: string;
  range: [number, number];
  name: string;
  description: string;
  targetState: string;
  badgeColor: string;
  borderColor: string;
}

export type MusicProvider = 'spotify' | 'youtube';

export interface MusicPreset {
  id: string;
  name: string;
  category: 'cardio' | 'strength' | 'recovery' | 'focus';
  provider: MusicProvider;
  title: string;
  subtitle: string;
  embedUrl: string;
  bpmOrVibe: string;
}

export interface MusicPlayerState {
  isOpen: boolean;
  isMinimized: boolean;
  provider: MusicProvider;
  currentPresetId: string;
  customUrl: string;
  activeEmbedUrl: string;
  activeTitle: string;
  activeSubtitle: string;
}
