import React from 'react';
import {
  Dumbbell,
  Sparkles,
  BarChart3,
  Sliders,
  Droplets,
  Plus,
  Headphones,
  Moon,
  Sun,
} from 'lucide-react';
import { ActiveTab } from '../types';

interface NavigationProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  hydrationOunces: number;
  hydrationTarget: number;
  onAddHydration: (oz: number) => void;
  onToggleMusic?: () => void;
  isMusicOpen?: boolean;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  hydrationOunces,
  hydrationTarget,
  onAddHydration,
  onToggleMusic,
  isMusicOpen,
  theme = 'dark',
  onToggleTheme,
}) => {
  const hydrationPercent = Math.min(100, Math.round((hydrationOunces / (hydrationTarget || 64)) * 100));
  const isDark = theme === 'dark';

  return (
    <header className={`${isDark ? 'bg-[#12091c]/95 border-[#2d1844]' : 'bg-white border-pf-purple-border/70'} border-b sticky top-0 z-30 shadow-xs transition-colors backdrop-blur-md`}>
      {/* Planet Fitness Signature Top Accent Stripe */}
      <div className="h-1.5 w-full bg-gradient-to-r from-pf-purple via-pf-yellow to-pf-purple" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand and Tag */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pf-purple text-pf-yellow flex items-center justify-center shadow-md ring-2 ring-pf-yellow/60">
              <Dumbbell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`font-extrabold ${isDark ? 'text-white' : 'text-pf-purple-deep'} text-base sm:text-lg tracking-tight`}>
                  Workout & Recovery
                </span>
                <span className="hidden sm:inline-block text-[10px] font-black uppercase tracking-wider bg-pf-yellow text-pf-purple-deep px-2 py-0.5 rounded-full shadow-2xs">
                  Judgement Free Zone®
                </span>
              </div>
              <p className={`text-[11px] ${isDark ? 'text-[#9f91ae]' : 'text-slate-500'} hidden sm:block`}>
                Planet Fitness Routine • Intensity tracking • Active rest timers • Milestones
              </p>
            </div>
          </div>

          {/* Hydration Quick-Log, Music Toggle & Theme Switcher */}
          <div className="flex items-center gap-2">
            <div className={`hidden md:flex items-center gap-2 ${isDark ? 'bg-[#1e1130] border-[#381f54]' : 'bg-pf-purple-surface border-pf-purple-border'} border px-3 py-1.5 rounded-xl text-xs`}>
              <Droplets className="w-3.5 h-3.5 text-pf-yellow" />
              <div className="flex items-baseline gap-1">
                <span className={`font-bold font-mono ${isDark ? 'text-white' : 'text-pf-purple-deep'}`}>{hydrationOunces}</span>
                <span className={`${isDark ? 'text-[#8e7e9f]' : 'text-slate-500'} text-[10px]`}>/ {hydrationTarget} oz</span>
              </div>
              <div className={`w-12 ${isDark ? 'bg-[#2d1844]' : 'bg-pf-purple-border'} rounded-full h-1.5 overflow-hidden ml-1`}>
                <div
                  className="bg-pf-yellow h-full rounded-full transition-all duration-300"
                  style={{ width: `${hydrationPercent}%` }}
                />
              </div>
              <button
                type="button"
                onClick={() => onAddHydration(8)}
                className="ml-1 px-1.5 py-0.5 hover:bg-pf-yellow hover:text-pf-purple-deep text-pf-yellow font-bold rounded transition-colors flex items-center gap-0.5 text-[10px] cursor-pointer"
                title="Add 8 oz water"
              >
                <Plus className="w-2.5 h-2.5" /> 8oz
              </button>
            </div>

            {/* Music Controls Button */}
            {onToggleMusic && (
              <button
                id="nav-music-toggle-btn"
                type="button"
                onClick={onToggleMusic}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  isMusicOpen
                    ? 'bg-pf-purple text-pf-yellow border-pf-purple-dark shadow-xs'
                    : isDark
                    ? 'bg-[#1e1130] hover:bg-[#281640] text-white border-[#381f54]'
                    : 'bg-pf-purple-surface hover:bg-pf-purple/10 text-pf-purple-deep border-pf-purple-border'
                }`}
                title="Toggle Workout Music (Spotify & YouTube Music)"
              >
                <div className="relative">
                  <Headphones className="w-3.5 h-3.5 text-pf-yellow" />
                  <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-pf-yellow rounded-full animate-pulse" />
                </div>
                <span className="hidden sm:inline">Music</span>
                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-bold ${
                  isMusicOpen ? 'bg-pf-yellow text-pf-purple-deep' : isDark ? 'bg-[#2c1844] text-pf-yellow' : 'bg-pf-purple/15 text-pf-purple-deep'
                }`}>
                  Spotify • YT
                </span>
              </button>
            )}

            {/* Dark / Light Mode Switcher */}
            {onToggleTheme && (
              <button
                id="nav-theme-toggle-btn"
                type="button"
                onClick={onToggleTheme}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                  isDark
                    ? 'bg-[#1e1130] hover:bg-[#281640] text-pf-yellow border-[#381f54]'
                    : 'bg-pf-purple-surface hover:bg-pf-purple/15 text-pf-purple-deep border-pf-purple-border'
                }`}
                title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {isDark ? <Sun className="w-3.5 h-3.5 text-pf-yellow" /> : <Moon className="w-3.5 h-3.5 text-pf-purple" />}
                <span className="hidden sm:inline">{isDark ? 'Dark Mode' : 'Light'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className={`flex space-x-1 sm:space-x-2 border-t ${isDark ? 'border-[#2d1844]' : 'border-pf-purple-border/40'} overflow-x-auto py-1.5 scrollbar-none`}>
          <button
            id="tab-active-workout"
            type="button"
            onClick={() => onSelectTab('workout')}
            className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'workout'
                ? 'bg-pf-purple text-white shadow-sm ring-1 ring-pf-yellow/60'
                : isDark
                ? 'text-[#a597b4] hover:text-white hover:bg-[#1e1130]'
                : 'text-slate-600 hover:text-pf-purple-deep hover:bg-pf-purple-surface'
            }`}
          >
            <Dumbbell className={`w-4 h-4 ${activeTab === 'workout' ? 'text-pf-yellow' : 'text-slate-400'}`} />
            <span>Active Workout (Gym Days)</span>
          </button>

          <button
            id="tab-spa-recovery"
            type="button"
            onClick={() => onSelectTab('recovery')}
            className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'recovery'
                ? 'bg-pf-purple text-white shadow-sm ring-1 ring-pf-yellow/60'
                : isDark
                ? 'text-[#a597b4] hover:text-white hover:bg-[#1e1130]'
                : 'text-slate-600 hover:text-pf-purple-deep hover:bg-pf-purple-surface'
            }`}
          >
            <Sparkles className={`w-4 h-4 ${activeTab === 'recovery' ? 'text-pf-yellow' : 'text-pf-purple-light'}`} />
            <span>Black Card® Spa (Recovery)</span>
          </button>

          <button
            id="tab-analytics"
            type="button"
            onClick={() => onSelectTab('analytics')}
            className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'analytics'
                ? 'bg-pf-purple text-white shadow-sm ring-1 ring-pf-yellow/60'
                : isDark
                ? 'text-[#a597b4] hover:text-white hover:bg-[#1e1130]'
                : 'text-slate-600 hover:text-pf-purple-deep hover:bg-pf-purple-surface'
            }`}
          >
            <BarChart3 className={`w-4 h-4 ${activeTab === 'analytics' ? 'text-pf-yellow' : 'text-slate-400'}`} />
            <span>Intensity & Recovery Analytics</span>
          </button>

          <button
            id="tab-custom-goals"
            type="button"
            onClick={() => onSelectTab('goals')}
            className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'goals'
                ? 'bg-pf-purple text-white shadow-sm ring-1 ring-pf-yellow/60'
                : isDark
                ? 'text-[#a597b4] hover:text-white hover:bg-[#1e1130]'
                : 'text-slate-600 hover:text-pf-purple-deep hover:bg-pf-purple-surface'
            }`}
          >
            <Sliders className={`w-4 h-4 ${activeTab === 'goals' ? 'text-pf-yellow' : 'text-slate-400'}`} />
            <span>Custom Goals</span>
          </button>
        </div>
      </div>
    </header>
  );
};

