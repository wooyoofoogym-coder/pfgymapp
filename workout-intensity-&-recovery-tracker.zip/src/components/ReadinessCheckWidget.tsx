import React, { useState } from 'react';
import {
  BatteryCharging,
  Moon,
  Zap,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { ReadinessCheck } from '../types';
import { calculateReadinessScore } from '../utils/progression';

interface ReadinessCheckWidgetProps {
  currentReadiness?: ReadinessCheck;
  onApplyReadiness: (readiness: ReadinessCheck) => void;
}

export const ReadinessCheckWidget: React.FC<ReadinessCheckWidgetProps> = ({
  currentReadiness,
  onApplyReadiness,
}) => {
  const [isExpanded, setIsExpanded] = useState(!currentReadiness);
  const [sleepQuality, setSleepQuality] = useState(currentReadiness?.sleepQuality || 4);
  const [energyLevel, setEnergyLevel] = useState(currentReadiness?.energyLevel || 4);
  const [muscleSoreness, setMuscleSoreness] = useState(currentReadiness?.muscleSoreness || 2);

  const activeAssessment = calculateReadinessScore(sleepQuality, energyLevel, muscleSoreness);

  const handleSaveAssessment = () => {
    onApplyReadiness(activeAssessment);
    setIsExpanded(false);
  };

  const getStatusBadge = (status: 'optimal' | 'moderate' | 'fatigued') => {
    switch (status) {
      case 'optimal':
        return {
          label: 'Optimal Readiness',
          classes: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          textColor: 'text-emerald-700',
          desc: 'Nervous system & muscles primed. Standard 60–75s rest intervals recommended.',
        };
      case 'moderate':
        return {
          label: 'Moderate Readiness',
          classes: 'bg-blue-100 text-blue-800 border-blue-300',
          textColor: 'text-blue-700',
          desc: 'Adequate recovery. Maintain steady 75s rest intervals and stay in target RPE 4–6.',
        };
      case 'fatigued':
        return {
          label: 'Elevated Fatigue',
          classes: 'bg-amber-100 text-amber-800 border-amber-300',
          textColor: 'text-amber-700',
          desc: 'Muscles or CNS need extra recovery time. 90s rest interval auto-suggested to preserve form.',
        };
    }
  };

  const statusInfo = getStatusBadge(activeAssessment.status);

  return (
    <div
      id="readiness-check-widget"
      className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-md transition-all overflow-hidden text-white"
    >
      {/* Header bar */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between cursor-pointer select-none"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-pf-purple text-pf-yellow flex items-center justify-center font-bold shadow-xs ring-1 ring-pf-yellow/40">
            <BatteryCharging className="w-5 h-5 text-pf-yellow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold text-white">Pre-Workout Recovery Readiness</h3>
              <span
                className={`text-[11px] px-2 py-0.5 rounded-full font-bold border ${statusInfo.classes}`}
              >
                {activeAssessment.readinessScore}% • {statusInfo.label}
              </span>
            </div>
            <p className="text-xs text-[#a597b4] mt-0.5">
              Calibrates session pacing and rest intervals based on your current systemic fatigue.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-[#a597b4] hidden sm:inline">
            Suggested Rest: <span className="text-pf-yellow font-bold font-mono">{activeAssessment.recommendedRestSeconds}s</span>
          </span>
          <button
            type="button"
            className="p-1.5 text-[#a597b4] hover:text-white rounded-lg hover:bg-[#201235]"
          >
            {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5 text-pf-yellow" />}
          </button>
        </div>
      </div>

      {/* Expanded Slider Controls */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-[#2d1942] space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Sleep Quality */}
            <div className="p-3 bg-[#1e122f] rounded-xl border border-[#351e4f]">
              <div className="flex items-center justify-between text-xs mb-2">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                  Sleep Quality
                </div>
                <span className="font-mono font-bold text-pf-yellow">{sleepQuality}/5</span>
              </div>
              <input
                id="sleep-quality-slider"
                type="range"
                min="1"
                max="5"
                step="1"
                value={sleepQuality}
                onChange={(e) => setSleepQuality(Number(e.target.value))}
                className="w-full accent-pf-yellow h-2 bg-[#2c1a42] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#8e7e9f] mt-1 font-medium">
                <span>Restless (1)</span>
                <span>Deep Sleep (5)</span>
              </div>
            </div>

            {/* Energy Level */}
            <div className="p-3 bg-[#1e122f] rounded-xl border border-[#351e4f]">
              <div className="flex items-center justify-between text-xs mb-2">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Zap className="w-3.5 h-3.5 text-pf-yellow" />
                  Energy Level
                </div>
                <span className="font-mono font-bold text-pf-yellow">{energyLevel}/5</span>
              </div>
              <input
                id="energy-level-slider"
                type="range"
                min="1"
                max="5"
                step="1"
                value={energyLevel}
                onChange={(e) => setEnergyLevel(Number(e.target.value))}
                className="w-full accent-pf-yellow h-2 bg-[#2c1a42] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#8e7e9f] mt-1 font-medium">
                <span>Drained (1)</span>
                <span>Energized (5)</span>
              </div>
            </div>

            {/* Muscle Soreness */}
            <div className="p-3 bg-[#1e122f] rounded-xl border border-[#351e4f]">
              <div className="flex items-center justify-between text-xs mb-2">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Activity className="w-3.5 h-3.5 text-rose-400" />
                  Muscle Soreness
                </div>
                <span className="font-mono font-bold text-pf-yellow">{muscleSoreness}/5</span>
              </div>
              <input
                id="muscle-soreness-slider"
                type="range"
                min="1"
                max="5"
                step="1"
                value={muscleSoreness}
                onChange={(e) => setMuscleSoreness(Number(e.target.value))}
                className="w-full accent-pf-yellow h-2 bg-[#2c1a42] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#8e7e9f] mt-1 font-medium">
                <span>Fresh (1)</span>
                <span>Sore / Tight (5)</span>
              </div>
            </div>
          </div>

          {/* Result & Recommendation banner */}
          <div className="p-3.5 rounded-xl bg-[#24133b] border border-[#3f2263] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-pf-yellow shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white">
                  Score: {activeAssessment.readinessScore}% — {statusInfo.label}
                </span>
                <p className="text-[#bfa9d8] mt-0.5">{statusInfo.desc}</p>
              </div>
            </div>

            <button
              id="apply-readiness-btn"
              type="button"
              onClick={handleSaveAssessment}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-pf-purple hover:bg-pf-purple-light text-white font-bold text-xs whitespace-nowrap cursor-pointer transition-colors shadow-2xs self-end sm:self-auto ring-1 ring-pf-yellow/40"
            >
              <CheckCircle2 className="w-4 h-4 text-pf-yellow" />
              Set Rest to {activeAssessment.recommendedRestSeconds}s & Apply
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
