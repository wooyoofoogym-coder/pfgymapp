import React, { useState } from 'react';
import {
  Sliders,
  Target,
  Dumbbell,
  Timer,
  HeartPulse,
  Droplets,
  Calendar,
  CheckCircle2,
  RotateCcw,
} from 'lucide-react';
import { CustomGoals, ProgressionTier } from '../types';
import { DEFAULT_CUSTOM_GOALS, DEFAULT_EXERCISES, TREADMILL_TIERS } from '../data/protocolDefaults';
import { playChime } from '../utils/audio';

interface CustomGoalsViewProps {
  goals: CustomGoals;
  onSaveGoals: (goals: CustomGoals) => void;
}

export const CustomGoalsView: React.FC<CustomGoalsViewProps> = ({
  goals,
  onSaveGoals,
}) => {
  const [formData, setFormData] = useState<CustomGoals>({ ...goals });
  const [savedToast, setSavedToast] = useState(false);

  const handleTierChange = (tier: ProgressionTier) => {
    if (tier !== 'custom') {
      const preset = TREADMILL_TIERS[tier];
      setFormData({
        ...formData,
        progressionTier: tier,
        customCardioIncline: preset.inclineMin,
        customCardioSpeed: preset.speedMin,
        customCardioMinutes: preset.defaultDurationMinutes,
      });
    } else {
      setFormData({
        ...formData,
        progressionTier: 'custom',
      });
    }
  };

  const handleExerciseTargetChange = (
    exId: string,
    field: 'targetWeightLbs' | 'targetReps' | 'targetSets',
    value: number
  ) => {
    setFormData({
      ...formData,
      exerciseTargets: {
        ...formData.exerciseTargets,
        [exId]: {
          ...(formData.exerciseTargets[exId] || { targetWeightLbs: 50, targetReps: 12, targetSets: 3 }),
          [field]: value,
        },
      },
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveGoals(formData);
    playChime('success');
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  const handleResetDefaults = () => {
    setFormData(DEFAULT_CUSTOM_GOALS);
    onSaveGoals(DEFAULT_CUSTOM_GOALS);
    playChime('success');
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 pb-12 text-white">
      {/* Header */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-black bg-pf-yellow text-pf-purple-deep shadow-2xs">
              Personalized Settings
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-white mt-1">Custom Goal Settings</h2>
          <p className="text-xs text-[#a597b4] mt-0.5">
            Configure your progression timeline targets, machine weight milestones, rest recovery durations, and intensity zones.
          </p>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border border-[#2d1942] text-[#a597b4] hover:bg-[#201233] hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Defaults
          </button>

          <button
            id="save-custom-goals-btn"
            type="submit"
            className="flex items-center gap-2 bg-pf-purple hover:bg-pf-purple-light text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer ring-2 ring-pf-yellow/60"
          >
            <CheckCircle2 className="w-4 h-4 text-pf-yellow" />
            Save Goals
          </button>
        </div>
      </div>

      {savedToast && (
        <div className="p-3 bg-[#0f241d] border border-emerald-800 text-emerald-300 rounded-xl text-xs font-medium flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          Custom fitness goals and target settings successfully saved!
        </div>
      )}

      {/* 1. Treadmill Progression Goals */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm">
        <div className="flex items-center gap-2 text-white font-extrabold text-base mb-1">
          <Target className="w-5 h-5 text-pf-yellow" />
          Incline Treadmill Progression Goals
        </div>
        <p className="text-xs text-[#a597b4] mb-4">
          Select standard timeline tier from the protocol or customize your own incline and speed targets.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          {(['weeks_1_2', 'weeks_3_4', 'weeks_5_6_plus', 'custom'] as ProgressionTier[]).map((tier) => {
            const isSelected = formData.progressionTier === tier;
            const info = TREADMILL_TIERS[tier];

            return (
              <button
                key={tier}
                type="button"
                onClick={() => handleTierChange(tier)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'border-pf-purple bg-[#25153b] ring-2 ring-pf-yellow/40 text-white'
                    : 'border-[#2d1942] hover:border-[#381f54] bg-[#1a0e28] text-white'
                }`}
              >
                <div className="font-bold text-white text-xs">{info.label}</div>
                <div className="text-[11px] text-[#a597b4] mt-1">
                  Incline: {info.inclineMin}% – {info.inclineMax}%
                </div>
                <div className="text-[11px] text-[#a597b4]">
                  Speed: {info.speedMin} – {info.speedMax} mph
                </div>
              </button>
            );
          })}
        </div>

        {/* Custom Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-[#1a0e28] p-4 rounded-xl border border-[#2d1942]">
          <div>
            <label className="block text-xs font-semibold text-[#a597b4] mb-1">Target Incline (%)</label>
            <div className="flex items-center gap-1.5">
              <input
                id="goal-incline-input"
                type="number"
                step="0.5"
                min="0"
                max="15"
                value={formData.customCardioIncline}
                onChange={(e) => setFormData({ ...formData, customCardioIncline: Number(e.target.value) })}
                className="w-full bg-[#140b20] border border-[#381f54] rounded-lg py-1.5 px-2.5 text-xs font-mono font-bold text-white focus:outline-hidden focus:border-pf-yellow focus:ring-1 focus:ring-pf-yellow"
              />
              <span className="text-xs text-[#a597b4] font-semibold">%</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#a597b4] mb-1">Target Speed (mph)</label>
            <div className="flex items-center gap-1.5">
              <input
                id="goal-speed-input"
                type="number"
                step="0.1"
                min="1.0"
                max="5.0"
                value={formData.customCardioSpeed}
                onChange={(e) => setFormData({ ...formData, customCardioSpeed: Number(e.target.value) })}
                className="w-full bg-[#140b20] border border-[#381f54] rounded-lg py-1.5 px-2.5 text-xs font-mono font-bold text-white focus:outline-hidden focus:border-pf-yellow focus:ring-1 focus:ring-pf-yellow"
              />
              <span className="text-xs text-[#a597b4] font-semibold">mph</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#a597b4] mb-1">Cardio Duration (Minutes)</label>
            <div className="flex items-center gap-1.5">
              <input
                id="goal-duration-input"
                type="number"
                min="10"
                max="60"
                value={formData.customCardioMinutes}
                onChange={(e) => setFormData({ ...formData, customCardioMinutes: Number(e.target.value) })}
                className="w-full bg-[#140b20] border border-[#381f54] rounded-lg py-1.5 px-2.5 text-xs font-mono font-bold text-white focus:outline-hidden focus:border-pf-yellow focus:ring-1 focus:ring-pf-yellow"
              />
              <span className="text-xs text-[#a597b4] font-semibold">min</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Machine Resistance Targets */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm">
        <div className="flex items-center gap-2 text-white font-extrabold text-base mb-1">
          <Dumbbell className="w-5 h-5 text-pf-yellow" />
          Resistance Circuit Machine Goals
        </div>
        <p className="text-xs text-[#a597b4] mb-4">
          Set custom target weight (lbs), target reps, and sets for each of the 5 resistance circuit machines.
        </p>

        <div className="space-y-3">
          {DEFAULT_EXERCISES.map((ex) => {
            const target = formData.exerciseTargets[ex.id] || {
              targetWeightLbs: ex.defaultWeight,
              targetReps: 12,
              targetSets: ex.defaultSets,
            };

            return (
              <div
                key={ex.id}
                className="p-3.5 rounded-xl border border-[#2d1942] bg-[#1a0e28] flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-[#381f54] transition-colors"
              >
                <div>
                  <div className="font-bold text-white text-xs">{ex.name}</div>
                  <div className="text-[11px] text-[#a597b4]">{ex.keyFocus}</div>
                </div>

                <div className="flex items-center gap-3">
                  <div>
                    <span className="text-[10px] text-[#8e7e9f] font-semibold uppercase block">Weight</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="5"
                        max="500"
                        step="5"
                        value={target.targetWeightLbs}
                        onChange={(e) =>
                          handleExerciseTargetChange(ex.id, 'targetWeightLbs', Number(e.target.value))
                        }
                        className="w-16 bg-[#140b20] border border-[#381f54] rounded py-1 px-2 text-xs font-mono font-bold text-pf-yellow focus:outline-hidden focus:border-pf-yellow focus:ring-1 focus:ring-pf-yellow"
                      />
                      <span className="text-[11px] text-[#a597b4]">lbs</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-[#8e7e9f] font-semibold uppercase block">Target Reps</span>
                    <input
                      type="number"
                      min="5"
                      max="30"
                      value={target.targetReps}
                      onChange={(e) =>
                        handleExerciseTargetChange(ex.id, 'targetReps', Number(e.target.value))
                      }
                      className="w-14 bg-[#140b20] border border-[#381f54] rounded py-1 px-2 text-xs font-mono font-bold text-white focus:outline-hidden focus:border-pf-yellow focus:ring-1 focus:ring-pf-yellow"
                    />
                  </div>

                  <div>
                    <span className="text-[10px] text-[#8e7e9f] font-semibold uppercase block">Target Sets</span>
                    <input
                      type="number"
                      min="1"
                      max="5"
                      value={target.targetSets}
                      onChange={(e) =>
                        handleExerciseTargetChange(ex.id, 'targetSets', Number(e.target.value))
                      }
                      className="w-12 bg-[#140b20] border border-[#381f54] rounded py-1 px-2 text-xs font-mono font-bold text-white focus:outline-hidden focus:border-pf-yellow focus:ring-1 focus:ring-pf-yellow"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Recovery Rest Timer & Intensity Zone Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Rest Recovery Window */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm">
          <div className="flex items-center gap-2 text-white font-extrabold text-sm mb-1">
            <Timer className="w-4 h-4 text-pf-yellow" />
            In-Workout Rest Interval Goal
          </div>
          <p className="text-xs text-[#a597b4] mb-3">
            Target rest interval between circuit sets to maximize muscular recovery.
          </p>

          <div className="flex items-center gap-3">
            <select
              value={formData.defaultRestTimerSeconds}
              onChange={(e) => setFormData({ ...formData, defaultRestTimerSeconds: Number(e.target.value) })}
              className="bg-[#140b20] border border-[#381f54] rounded-xl py-2 px-3 text-xs font-bold text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
            >
              <option value="60">60 Seconds (Rapid recovery)</option>
              <option value="75">75 Seconds (Protocol standard)</option>
              <option value="90">90 Seconds (Strength & heavy load)</option>
              <option value="120">120 Seconds (Extended rest)</option>
            </select>
            <span className="text-xs text-[#a597b4]">Auto-launches upon set completion</span>
          </div>
        </div>

        {/* Target Intensity Zone */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm">
          <div className="flex items-center gap-2 text-white font-extrabold text-sm mb-1">
            <HeartPulse className="w-4 h-4 text-pf-yellow" />
            Target Exertion (RPE) Zone
          </div>
          <p className="text-xs text-[#a597b4] mb-3">
            Recommended protocol range is RPE 4–6 (steady breathing & sustainable effort).
          </p>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-[#a597b4] font-semibold">Min:</span>
              <input
                type="number"
                min="1"
                max="9"
                value={formData.targetMinRpe}
                onChange={(e) => setFormData({ ...formData, targetMinRpe: Number(e.target.value) })}
                className="w-14 bg-[#140b20] border border-[#381f54] rounded-lg py-1 px-2 text-center font-bold text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
              />
            </div>
            <span className="text-[#8e7e9f] font-bold">—</span>
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-[#a597b4] font-semibold">Max:</span>
              <input
                type="number"
                min="2"
                max="10"
                value={formData.targetMaxRpe}
                onChange={(e) => setFormData({ ...formData, targetMaxRpe: Number(e.target.value) })}
                className="w-14 bg-[#140b20] border border-[#381f54] rounded-lg py-1 px-2 text-center font-bold text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
              />
            </div>
            <span className="text-xs font-black text-pf-purple-deep bg-pf-yellow px-2.5 py-1 rounded-md shadow-2xs">
              RPE {formData.targetMinRpe}–{formData.targetMaxRpe}
            </span>
          </div>
        </div>

        {/* Weekly Split Frequency */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm">
          <div className="flex items-center gap-2 text-white font-extrabold text-sm mb-1">
            <Calendar className="w-4 h-4 text-pf-yellow" />
            Weekly Routine Frequency
          </div>
          <p className="text-xs text-[#a597b4] mb-3">
            Standard protocol: 3 active gym sessions (Mon/Wed/Fri) & 2 spa days (Tue/Thu).
          </p>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-[#a597b4] font-medium mb-1">Gym Days / Week</label>
              <input
                type="number"
                min="1"
                max="7"
                value={formData.weeklyGymDaysTarget}
                onChange={(e) => setFormData({ ...formData, weeklyGymDaysTarget: Number(e.target.value) })}
                className="w-full bg-[#140b20] border border-[#381f54] rounded-lg py-1.5 px-2 font-bold text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
              />
            </div>
            <div>
              <label className="block text-[#a597b4] font-medium mb-1">Spa Days / Week</label>
              <input
                type="number"
                min="0"
                max="7"
                value={formData.weeklySpaDaysTarget}
                onChange={(e) => setFormData({ ...formData, weeklySpaDaysTarget: Number(e.target.value) })}
                className="w-full bg-[#140b20] border border-[#381f54] rounded-lg py-1.5 px-2 font-bold text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
              />
            </div>
          </div>
        </div>

        {/* Daily Hydration Goal */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm">
          <div className="flex items-center gap-2 text-white font-extrabold text-sm mb-1">
            <Droplets className="w-4 h-4 text-pf-yellow" />
            Daily Hydration Target
          </div>
          <p className="text-xs text-[#a597b4] mb-3">
            Hydrate with water and electrolytes prior to training and spa recovery.
          </p>

          <div className="flex items-center gap-2">
            <input
              type="number"
              min="20"
              max="200"
              step="4"
              value={formData.dailyHydrationOzTarget}
              onChange={(e) => setFormData({ ...formData, dailyHydrationOzTarget: Number(e.target.value) })}
              className="w-24 bg-[#140b20] border border-[#381f54] rounded-lg py-1.5 px-2 text-xs font-mono font-bold text-white"
            />
            <span className="text-xs font-semibold text-[#a597b4]">Fluid Ounces / Day</span>
            <span className="text-xs text-[#8e7e9f]">
              (~{(formData.dailyHydrationOzTarget * 0.02957).toFixed(1)} Liters)
            </span>
          </div>
        </div>
      </div>
    </form>
  );
};
