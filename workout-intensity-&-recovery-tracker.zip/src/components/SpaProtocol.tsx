import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Clock,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Droplets,
  Wind,
  Shield,
  Sun,
  Flame,
  CheckSquare,
  Square,
  Activity,
  TrendingDown,
  Headphones,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SpaAmenity, SpaSession } from '../types';
import { DEFAULT_SPA_AMENITIES } from '../data/protocolDefaults';
import { playChime } from '../utils/audio';

interface SpaProtocolProps {
  onSaveSpaSession: (session: SpaSession) => void;
  onNavigateToAnalytics: () => void;
  onTriggerMusic?: (category: 'cardio' | 'strength' | 'recovery' | 'focus') => void;
}

export const SpaProtocol: React.FC<SpaProtocolProps> = ({
  onSaveSpaSession,
  onNavigateToAnalytics,
  onTriggerMusic,
}) => {
  const [amenities, setAmenities] = useState<SpaAmenity[]>(DEFAULT_SPA_AMENITIES);
  const [activeAmenityId, setActiveAmenityId] = useState<string | null>(null);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [prepChecklist, setPrepChecklist] = useState({
    showerExfoliate: false,
    noLotionPerfume: false,
    hydrateElectrolytes: false,
  });
  const [sorenessBefore, setSorenessBefore] = useState<number>(3);
  const [sorenessAfter, setSorenessAfter] = useState<number>(1);
  const [targetMuscleGroup, setTargetMuscleGroup] = useState<string>('Full Body / Legs & Back');
  const [notes, setNotes] = useState('');

  // Count active timers
  useEffect(() => {
    if (!isTimerRunning || !activeAmenityId) return;

    const interval = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsTimerRunning(false);
          // Mark active amenity as completed
          setAmenities((prevA) =>
            prevA.map((a) => (a.id === activeAmenityId ? { ...a, completed: true } : a))
          );
          playChime('success');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isTimerRunning, activeAmenityId]);

  const handleStartAmenityTimer = (amenity: SpaAmenity) => {
    setActiveAmenityId(amenity.id);
    setRemainingSeconds(amenity.defaultMinutes * 60);
    setIsTimerRunning(true);
  };

  const handleToggleAmenityCompleted = (id: string) => {
    setAmenities((prev) =>
      prev.map((a) => (a.id === id ? { ...a, completed: !a.completed } : a))
    );
  };

  const handleSaveRecoverySession = () => {
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {}

    const totalMin = amenities.reduce(
      (sum, a) => sum + (a.completed ? a.defaultMinutes : 0),
      0
    );

    const session: SpaSession = {
      id: `spa-${Date.now()}`,
      date: new Date().toISOString(),
      amenities: amenities.map((a) => ({
        amenityId: a.id,
        name: a.name,
        durationMinutes: a.defaultMinutes,
        completed: a.completed,
      })),
      totalDurationMinutes: totalMin || 30,
      sorenessBefore,
      sorenessAfter,
      targetMuscleGroup,
      notes: notes || `Dedicated Rest Day Recovery Protocol completed. Target: ${targetMuscleGroup}. Soreness reduced from ${sorenessBefore}/5 to ${sorenessAfter}/5.`,
    };

    onSaveSpaSession(session);
    playChime('success');
    onNavigateToAnalytics();
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const totalRecoveryMinutes = amenities.reduce((acc, a) => acc + (a.completed ? a.defaultMinutes : 0), 0);
  const completedCount = amenities.filter((a) => a.completed).length;

  return (
    <div className="space-y-6 pb-12">
      {/* Recovery Day Header */}
      <div
        id="spa-protocol-header"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-white"
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-black bg-pf-yellow text-pf-purple-deep shadow-2xs">
              Dedicated Recovery Protocol
            </span>
            <span className="text-xs text-[#a597b4] font-bold">Tue / Thu Split</span>
          </div>
          <h2 className="text-xl font-extrabold text-white mt-1">Rest Day Recovery & Spa Routine</h2>
          <p className="text-xs text-[#a597b4] mt-0.5">
            Black Card® Spa recovery, skin circulation, and restorative relaxation across 4 specialized stations.
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          <div className="flex items-center gap-2 bg-[#1f1330] border border-[#381f54] px-3.5 py-2 rounded-xl text-xs">
            <Clock className="w-4 h-4 text-pf-yellow" />
            <div>
              <div className="text-[10px] text-pf-yellow font-bold uppercase">Recovery Logged</div>
              <div className="font-mono font-extrabold text-white text-sm">{totalRecoveryMinutes} Mins</div>
            </div>
          </div>

          {onTriggerMusic && (
            <button
              id="spa-music-trigger-btn"
              type="button"
              onClick={() => onTriggerMusic('recovery')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-[#1e1130] text-pf-yellow border border-[#381f54] hover:bg-pf-yellow hover:text-pf-purple-deep transition-all cursor-pointer shadow-2xs"
              title="Launch 432Hz Recovery Soundscape"
            >
              <Headphones className="w-3.5 h-3.5 text-pf-yellow" />
              <span className="hidden sm:inline">432Hz Audio</span>
            </button>
          )}

          <button
            id="save-spa-session-btn"
            type="button"
            onClick={handleSaveRecoverySession}
            className="flex items-center gap-2 bg-pf-purple hover:bg-pf-purple-light text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer ring-2 ring-pf-yellow/60"
          >
            <CheckCircle2 className="w-4 h-4 text-pf-yellow" />
            Save Recovery Day
          </button>
        </div>
      </div>

      {/* Preparation & Guidelines Protocol Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* At-Home Prep Checklist */}
        <div className="bg-[#160e22] rounded-xl border border-[#2d1942] p-4 text-white">
          <div className="flex items-center gap-2 text-pf-yellow font-bold text-sm mb-2">
            <Droplets className="w-4 h-4 text-pf-yellow" />
            At-Home Prep (2–4 Hours Prior)
          </div>
          <p className="text-xs text-[#a597b4] mb-3">
            Proper preparation ensures maximum absorption and amenity effectiveness.
          </p>
          <div className="space-y-2 text-xs">
            <label className="flex items-center gap-2 text-[#d0c2df] cursor-pointer">
              <input
                type="checkbox"
                checked={prepChecklist.showerExfoliate}
                onChange={(e) => setPrepChecklist({ ...prepChecklist, showerExfoliate: e.target.checked })}
                className="w-4 h-4 rounded text-pf-yellow accent-pf-yellow"
              />
              <span>Shower & exfoliate thoroughly before leaving home</span>
            </label>
            <label className="flex items-center gap-2 text-[#d0c2df] cursor-pointer">
              <input
                type="checkbox"
                checked={prepChecklist.noLotionPerfume}
                onChange={(e) => setPrepChecklist({ ...prepChecklist, noLotionPerfume: e.target.checked })}
                className="w-4 h-4 rounded text-pf-yellow accent-pf-yellow"
              />
              <span>Do not apply lotion, perfume, body oil, or deodorant</span>
            </label>
            <label className="flex items-center gap-2 text-[#d0c2df] cursor-pointer">
              <input
                type="checkbox"
                checked={prepChecklist.hydrateElectrolytes}
                onChange={(e) => setPrepChecklist({ ...prepChecklist, hydrateElectrolytes: e.target.checked })}
                className="w-4 h-4 rounded text-pf-yellow accent-pf-yellow"
              />
              <span>Drink 16–20 oz water beforehand for deep tissue hydration</span>
            </label>
          </div>
        </div>

        {/* Post-Spa Rules Guide */}
        <div className="bg-[#160e22] rounded-xl border border-[#2d1942] p-4 text-white">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            Post-Recovery Rules
          </div>
          <p className="text-xs text-[#a597b4] mb-3">
            Allow treatments to set into skin tissue and muscles uninterrupted.
          </p>
          <ul className="space-y-2 text-xs text-[#d0c2df] list-disc list-inside">
            <li>Wear loose, dark, comfortable clothing upon exiting.</li>
            <li>Wait <span className="font-bold text-white">6 to 8 hours</span> before taking a shower.</li>
            <li>Take a lukewarm water-only rinse at home (no harsh soaps or abrasive loofahs).</li>
            <li>Rehydrate with electrolytes to replenish recovered muscles.</li>
          </ul>
        </div>
      </div>

      {/* Active Amenity Timer Bar (if running) */}
      {activeAmenityId && (
        <div className="bg-[#1e1130] text-white rounded-2xl p-4 shadow-xl border border-[#381f54] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full border-2 border-pf-yellow text-pf-yellow flex items-center justify-center font-mono font-extrabold text-lg">
              {formatTime(remainingSeconds)}
            </div>
            <div>
              <div className="text-xs text-pf-yellow uppercase tracking-wider font-bold">Active Amenity Station</div>
              <div className="text-base font-extrabold text-white">
                {amenities.find((a) => a.id === activeAmenityId)?.name}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-extrabold transition-all ${
                isTimerRunning ? 'bg-amber-500 text-white hover:bg-amber-600' : 'bg-pf-yellow text-pf-purple-deep hover:bg-pf-yellow-hover'
              }`}
            >
              {isTimerRunning ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
              {isTimerRunning ? 'Pause' : 'Resume'}
            </button>
            <button
              type="button"
              onClick={() => {
                const item = amenities.find((a) => a.id === activeAmenityId);
                if (item) setRemainingSeconds(item.defaultMinutes * 60);
              }}
              className="p-2 rounded-xl bg-[#25153b] text-[#a597b4] hover:text-white border border-[#381f54]"
              title="Reset timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                setAmenities((prev) =>
                  prev.map((a) => (a.id === activeAmenityId ? { ...a, completed: true } : a))
                );
                setIsTimerRunning(false);
                setActiveAmenityId(null);
              }}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              Finish Amenity
            </button>
          </div>
        </div>
      )}

      {/* 4 Specialized Amenity Cards */}
      <div className="space-y-3">
        <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
          Recovery Stations Progression ({completedCount}/4 Completed)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {amenities.map((amenity) => {
            const isSelected = activeAmenityId === amenity.id;

            return (
              <div
                key={amenity.id}
                id={`amenity-card-${amenity.id}`}
                className={`rounded-2xl border p-5 transition-all text-white ${
                  amenity.completed
                    ? 'border-emerald-600 bg-[#0f241d]/50 shadow-2xs'
                    : isSelected
                    ? 'bg-[#1b1029] border-pf-purple ring-2 ring-pf-yellow/30'
                    : 'bg-[#160e22] border-[#2d1942] hover:border-[#422562] shadow-2xs'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-pf-purple font-extrabold text-pf-yellow flex items-center justify-center text-xs shadow-xs ring-1 ring-pf-yellow/40">
                      {amenity.order}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-base">{amenity.name}</h4>
                      <span className="text-xs font-bold text-pf-yellow">{amenity.defaultMinutes} Minutes Target</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleAmenityCompleted(amenity.id)}
                    className="cursor-pointer"
                    title={amenity.completed ? 'Mark uncompleted' : 'Mark completed'}
                  >
                    <CheckCircle2
                      className={`w-6 h-6 transition-colors ${
                        amenity.completed ? 'text-emerald-400 fill-emerald-950/40' : 'text-[#5d4f6c] hover:text-[#8e7e9f]'
                      }`}
                    />
                  </button>
                </div>

                <div className="mt-3 space-y-1.5 text-xs">
                  <div className="text-[#d0c2df]">
                    <span className="font-semibold text-white">Purpose:</span> {amenity.purpose}
                  </div>
                  <div className="text-[#a597b4] bg-[#1a0e28] p-2.5 rounded-lg border border-[#2f1a45]">
                    <span className="font-semibold text-white">Action Rule:</span> {amenity.actionRule}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#2d1942] flex items-center justify-between">
                  <span className="text-[11px] text-[#8e7e9f]">
                    {amenity.completed ? 'Station logged' : 'Ready to start'}
                  </span>

                  <button
                    type="button"
                    onClick={() => handleStartAmenityTimer(amenity)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-pf-purple hover:bg-pf-purple-light text-white shadow-2xs transition-colors cursor-pointer ring-1 ring-pf-yellow/40"
                  >
                    <Play className="w-3.5 h-3.5 fill-current text-pf-yellow" />
                    Start {amenity.defaultMinutes}m Timer
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Muscular Soreness & Recovery Relief Assessment */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-xs space-y-4 text-white">
        <div className="flex items-center justify-between pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-pf-purple text-pf-yellow flex items-center justify-center font-bold shadow-xs ring-1 ring-pf-yellow/40">
              <Activity className="w-4 h-4 text-pf-yellow" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-white">Perceived Muscle Soreness & Fatigue Assessment</h3>
              <p className="text-xs text-[#a597b4]">
                Track how passive modalities (HydroMassage, Total Body Enhancement, Recovery Chair) accelerate post-workout tissue recovery.
              </p>
            </div>
          </div>

          {sorenessBefore > sorenessAfter && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#0d221a] text-emerald-300 border border-[#164a38] text-xs font-bold">
              <TrendingDown className="w-3.5 h-3.5 text-emerald-400" />
              <span>-{sorenessBefore - sorenessAfter} pts Soreness Relief</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Target Muscle Group */}
          <div className="p-3.5 bg-[#1a0e28] rounded-xl border border-[#2f1a45]">
            <label className="block text-xs font-bold text-[#d0c2df] mb-1.5">
              Primary Muscle Focus
            </label>
            <select
              id="target-muscle-group-select"
              value={targetMuscleGroup}
              onChange={(e) => setTargetMuscleGroup(e.target.value)}
              className="w-full text-xs font-semibold bg-[#140b20] border border-[#381f54] rounded-lg p-2 text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
            >
              <option value="Full Body / Legs & Back">Full Body / Legs & Back</option>
              <option value="Legs & Glutes (Leg Press recovery)">Legs & Glutes (Leg Press recovery)</option>
              <option value="Upper Body / Chest & Lat Pulls">Upper Body / Chest & Lat Pulls</option>
              <option value="Core & Spinal Decompression">Core & Spinal Decompression</option>
              <option value="Calves & Shin Splints (Incline walk)">Calves & Shin Splints (Incline walk)</option>
            </select>
            <p className="text-[10px] text-[#8e7e9f] mt-1">Direct HydroMassage water jets to this region</p>
          </div>

          {/* Soreness Before */}
          <div className="p-3.5 bg-[#1a0e28] rounded-xl border border-[#2f1a45]">
            <div className="flex items-center justify-between text-xs font-bold text-[#d0c2df] mb-1.5">
              <span>Soreness Before Recovery</span>
              <span className="font-mono text-rose-400 font-bold">{sorenessBefore} / 5</span>
            </div>
            <input
              id="soreness-before-slider"
              type="range"
              min="1"
              max="5"
              step="1"
              value={sorenessBefore}
              onChange={(e) => setSorenessBefore(Number(e.target.value))}
              className="w-full accent-pf-yellow h-2 bg-[#2c1844] rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#8e7e9f] mt-1">
              <span>1 (Mild stiffness)</span>
              <span>5 (Deep fatigue)</span>
            </div>
          </div>

          {/* Soreness After */}
          <div className="p-3.5 bg-[#1a0e28] rounded-xl border border-[#2f1a45]">
            <div className="flex items-center justify-between text-xs font-bold text-[#d0c2df] mb-1.5">
              <span>Soreness After Recovery</span>
              <span className="font-mono text-emerald-400 font-bold">{sorenessAfter} / 5</span>
            </div>
            <input
              id="soreness-after-slider"
              type="range"
              min="1"
              max="5"
              step="1"
              value={sorenessAfter}
              onChange={(e) => setSorenessAfter(Number(e.target.value))}
              className="w-full accent-pf-yellow h-2 bg-[#2c1844] rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#8e7e9f] mt-1">
              <span>1 (Fully relaxed)</span>
              <span>5 (Unchanged)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recovery Session Notes */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-xs text-white">
        <label className="block text-xs font-bold text-white uppercase tracking-wider mb-2">
          Recovery Day Notes & Perceived Soreness
        </label>
        <textarea
          id="recovery-notes-input"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="e.g., Felt muscle soreness in calves and upper back diminish after HydroMassage bed. Skin felt refreshed."
          className="w-full text-xs p-3 rounded-xl border border-[#381f54] bg-[#140b20] text-white placeholder-[#7a6b8d] focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
          rows={3}
        />
      </div>
    </div>
  );
};
