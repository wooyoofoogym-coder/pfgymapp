import React, { useState } from 'react';
import {
  Activity,
  HeartPulse,
  Timer,
  Calendar,
  ChevronDown,
  ChevronUp,
  Trash2,
  Award,
  Zap,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Dumbbell,
  Droplet,
  BatteryCharging,
  Moon,
  Sparkles,
} from 'lucide-react';
import { CustomGoals, SpaSession, WorkoutSession } from '../types';
import { RPE_GUIDE_LEVELS } from '../data/protocolDefaults';

interface IntensityAnalyticsProps {
  workouts: WorkoutSession[];
  spaSessions: SpaSession[];
  customGoals: CustomGoals;
  onDeleteWorkout: (id: string) => void;
}

export const IntensityAnalytics: React.FC<IntensityAnalyticsProps> = ({
  workouts,
  spaSessions,
  customGoals,
  onDeleteWorkout,
}) => {
  const [expandedWorkoutId, setExpandedWorkoutId] = useState<string | null>(
    workouts.length > 0 ? workouts[0].id : null
  );

  // Compute stats
  const totalWorkouts = workouts.length;
  const totalSpaDays = spaSessions.length;

  // Average RPE across all sessions
  const avgOverallRpe =
    totalWorkouts > 0
      ? (
          workouts.reduce((sum, w) => sum + (w.averageRpe || 5), 0) /
          totalWorkouts
        ).toFixed(1)
      : '5.0';

  // Total Recovery Time (seconds from in-circuit rest + minutes from post workout hydro + minutes from spa)
  const totalInCircuitRestSeconds = workouts.reduce(
    (sum, w) => sum + (w.totalRestRecoverySeconds || 0),
    0
  );
  const totalPostHydroMinutes = workouts.reduce(
    (sum, w) => sum + (w.postWorkoutHydroMinutes || 0),
    0
  );
  const totalSpaMinutes = spaSessions.reduce(
    (sum, s) => sum + (s.totalDurationMinutes || 0),
    0
  );
  const cumulativeRecoveryMinutes = Math.round(
    totalInCircuitRestSeconds / 60 + totalPostHydroMinutes + totalSpaMinutes
  );

  // Target Zone Adherence (percentage of sets with RPE between 4 and 6)
  let totalSetsLogged = 0;
  let setsInTargetZone = 0;
  workouts.forEach((w) => {
    w.exercises?.forEach((ex) => {
      ex.sets?.forEach((set) => {
        if (set.completed) {
          totalSetsLogged++;
          if (set.rpe >= 4 && set.rpe <= 6) {
            setsInTargetZone++;
          }
        }
      });
    });
  });

  const targetZoneAdherencePercent =
    totalSetsLogged > 0
      ? Math.round((setsInTargetZone / totalSetsLogged) * 100)
      : 88;

  // Cumulative Volume (Tonnage)
  const totalCumulativeVolumeLbs = workouts.reduce((sum, w) => {
    if (w.totalVolumeLbs) return sum + w.totalVolumeLbs;
    const vol =
      w.exercises?.reduce(
        (v, ex) =>
          v +
          ex.sets.reduce(
            (sSum, s) => (s.completed ? sSum + s.weightLbs * s.actualReps : sSum),
            0
          ),
        0
      ) || 0;
    return sum + vol;
  }, 0);

  // Machine volume breakdown
  const machineStats: Record<
    string,
    { name: string; keyFocus: string; totalVolume: number; latestWeight: number; totalReps: number }
  > = {};

  workouts.forEach((w) => {
    w.exercises?.forEach((ex) => {
      if (!machineStats[ex.exerciseId]) {
        machineStats[ex.exerciseId] = {
          name: ex.name,
          keyFocus: ex.keyFocus,
          totalVolume: 0,
          latestWeight: ex.sets[0]?.weightLbs || 0,
          totalReps: 0,
        };
      }
      ex.sets?.forEach((s) => {
        if (s.completed) {
          machineStats[ex.exerciseId].totalVolume += s.weightLbs * s.actualReps;
          machineStats[ex.exerciseId].totalReps += s.actualReps;
          if (s.weightLbs > machineStats[ex.exerciseId].latestWeight) {
            machineStats[ex.exerciseId].latestWeight = s.weightLbs;
          }
        }
      });
    });
  });

  // Soreness reduction stats from Spa sessions
  const sessionsWithSoreness = spaSessions.filter(
    (s) => s.sorenessBefore !== undefined && s.sorenessAfter !== undefined
  );
  const avgSorenessRelief =
    sessionsWithSoreness.length > 0
      ? (
          sessionsWithSoreness.reduce(
            (sum, s) => sum + (s.sorenessBefore! - s.sorenessAfter!),
            0
          ) / sessionsWithSoreness.length
        ).toFixed(1)
      : '1.8';

  const workoutsWithReadiness = workouts.filter((w) => w.readiness);
  const avgReadinessScore =
    workoutsWithReadiness.length > 0
      ? Math.round(
          workoutsWithReadiness.reduce((sum, w) => sum + (w.readiness?.readinessScore || 75), 0) /
            workoutsWithReadiness.length
        )
      : 82;

  const formatDate = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Workout Intensity Average */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#a597b4] uppercase tracking-wider">
              Workout Intensity
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#25153b] text-pf-yellow flex items-center justify-center">
              <HeartPulse className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-mono">
              RPE {avgOverallRpe}
            </span>
            <span className="text-xs font-black text-pf-purple-deep bg-pf-yellow px-2 py-0.5 rounded-md shadow-2xs">
              Zone 4–6 Target
            </span>
          </div>
          <p className="text-xs text-[#a597b4] mt-2">
            Average exertion level tracked across cardio progressions & resistance sets.
          </p>
        </div>

        {/* Target Zone Adherence */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#a597b4] uppercase tracking-wider">
              Target Zone Precision
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#0f241d] text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-400 font-mono">
              {targetZoneAdherencePercent}%
            </span>
            <span className="text-xs text-[#a597b4] font-semibold">In 4–6 RPE</span>
          </div>
          <p className="text-xs text-[#a597b4] mt-2">
            {setsInTargetZone} of {totalSetsLogged} completed sets performed within optimal breathing zone.
          </p>
        </div>

        {/* Total Cumulative Recovery Time */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#a597b4] uppercase tracking-wider">
              Recovery Time Logged
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#25153b] text-pf-yellow flex items-center justify-center">
              <Timer className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-mono">
              {cumulativeRecoveryMinutes}
            </span>
            <span className="text-xs font-semibold text-[#a597b4]">Total Minutes</span>
          </div>
          <p className="text-xs text-[#a597b4] mt-2">
            Includes between-set rest intervals, HydroMassage bed, and dedicated spa circuits.
          </p>
        </div>

        {/* Weekly Consistency Goal */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#a597b4] uppercase tracking-wider">
              Weekly Goal Progress
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#281b10] text-amber-400 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-3 text-xs">
            <div>
              <div className="font-bold text-pf-yellow text-lg">
                {Math.min(customGoals.weeklyGymDaysTarget, totalWorkouts)} / {customGoals.weeklyGymDaysTarget}
              </div>
              <span className="text-[10px] text-[#a597b4] uppercase font-semibold">Gym Days</span>
            </div>
            <div className="h-6 w-px bg-[#2d1942]" />
            <div>
              <div className="font-bold text-pf-yellow text-lg">
                {Math.min(customGoals.weeklySpaDaysTarget, totalSpaDays)} / {customGoals.weeklySpaDaysTarget}
              </div>
              <span className="text-[10px] text-[#a597b4] uppercase font-semibold">Spa Days</span>
            </div>
          </div>
          <p className="text-xs text-[#a597b4] mt-2">
            Balanced split: 3 active training days & 2 dedicated restorative days.
          </p>
        </div>
      </div>

      {/* RPE EXERTION REFERENCE SCALE */}
      <div
        id="rpe-reference-card"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#2d1942]">
          <div>
            <h3 className="text-base font-extrabold text-white">RPE Exertion Reference Scale</h3>
            <p className="text-xs text-[#a597b4]">
              Rate of Perceived Exertion (1–10) standardized intensity guide used across all sessions.
            </p>
          </div>
          <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-black bg-pf-yellow text-pf-purple-deep shadow-2xs self-start sm:self-auto">
            Target Zone: Levels 4–6
          </span>
        </div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {RPE_GUIDE_LEVELS.map((guide) => {
            const isTarget = guide.level === '4–6';

            return (
              <div
                key={guide.level}
                className={`p-4 rounded-xl border transition-all ${
                  isTarget
                    ? 'bg-[#25153b] border-pf-purple ring-2 ring-pf-yellow/30 text-white'
                    : 'bg-[#1a0e28] border-[#2f1a45] text-white'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-black font-mono text-white">
                    RPE {guide.level}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${guide.badgeColor}`}>
                    {guide.targetState}
                  </span>
                </div>
                <div className="font-bold text-xs text-pf-yellow mb-1">{guide.name}</div>
                <p className="text-xs text-[#a597b4] leading-relaxed">{guide.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* VOLUME & PROGRESSIVE OVERLOAD MILESTONES */}
      <div
        id="volume-progression-card"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm space-y-4 text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-pf-purple text-pf-yellow flex items-center justify-center font-bold ring-1 ring-pf-yellow/40">
              <Dumbbell className="w-5 h-5 text-pf-yellow" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Total Volume & Progressive Overload Milestones</h3>
              <p className="text-xs text-[#a597b4]">
                Tracks cumulative tonnage (Weight × Reps × Sets) per machine to verify strength adaptation.
              </p>
            </div>
          </div>

          <div className="flex items-baseline gap-1.5 self-start sm:self-auto bg-[#1f1330] border border-[#381f54] px-3 py-1.5 rounded-xl">
            <span className="text-[10px] uppercase font-bold text-pf-yellow">Cumulative Tonnage:</span>
            <span className="text-base font-black text-white font-mono">
              {totalCumulativeVolumeLbs.toLocaleString()} lbs
            </span>
          </div>
        </div>

        {/* Machine Breakdown Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
          {Object.entries(machineStats).length === 0 ? (
            <div className="col-span-full text-center py-6 text-[#8e7e9f] text-xs">
              Complete sets in the active workout to generate machine-specific volume tracking.
            </div>
          ) : (
            Object.entries(machineStats).map(([id, stat]) => (
              <div
                key={id}
                className="p-3.5 bg-[#1a0e28] rounded-xl border border-[#2f1a45] flex flex-col justify-between text-white"
              >
                <div>
                  <div className="text-xs font-bold text-white truncate" title={stat.name}>
                    {stat.name}
                  </div>
                  <div className="text-[10px] text-[#8e7e9f] mb-2 truncate">{stat.keyFocus}</div>

                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between text-[#a597b4]">
                      <span>Volume:</span>
                      <span className="font-mono font-bold text-pf-yellow">
                        {stat.totalVolume.toLocaleString()} lbs
                      </span>
                    </div>
                    <div className="flex justify-between text-[#a597b4]">
                      <span>Peak:</span>
                      <span className="font-mono font-bold text-white">{stat.latestWeight} lbs</span>
                    </div>
                    <div className="flex justify-between text-[#a597b4]">
                      <span>Reps:</span>
                      <span className="font-mono font-medium text-white">{stat.totalReps}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-[#2d1942] flex items-center justify-between text-[10px] font-semibold text-emerald-400">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    Overload Ready
                  </span>
                  <span className="text-[#8e7e9f]">RPE ≤ 6</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* RECOVERY READINESS & SORENESS RELIEF IMPACT */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pre-Workout Readiness Trend */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-[#2d1942]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#25153b] text-pf-yellow flex items-center justify-center font-bold">
                  <BatteryCharging className="w-4 h-4 text-pf-yellow" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Systemic Recovery Readiness</h4>
                  <p className="text-[11px] text-[#a597b4]">Sleep, CNS freshness, and pacing correlation</p>
                </div>
              </div>
              <span className="text-sm font-extrabold text-pf-yellow font-mono">
                {avgReadinessScore}% Avg
              </span>
            </div>

            <div className="mt-3 space-y-2 text-xs text-[#d0c2df]">
              <p>
                Pre-workout readiness scores dictate between-set rest windows (60s, 75s, or 90s) to safeguard form and maintain explosive eccentric tempo.
              </p>
              <div className="p-2.5 rounded-lg bg-[#1a0e28] border border-[#2f1a45] flex items-center justify-between text-[11px]">
                <span className="font-semibold text-pf-yellow">Rest Interval Calibration:</span>
                <span className="text-[#a597b4] font-medium">Auto-scales to 90s when soreness &gt; 3</span>
              </div>
            </div>
          </div>
        </div>

        {/* Muscular Soreness Relief Metric */}
        <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-[#2d1942]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#0f241d] text-emerald-400 flex items-center justify-center font-bold">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Restorative Spa Soreness Relief</h4>
                  <p className="text-[11px] text-[#a597b4]">HydroMassage, Red-Light & Cryo efficacy</p>
                </div>
              </div>
              <span className="text-sm font-extrabold text-emerald-400 font-mono flex items-center gap-1">
                <TrendingDown className="w-4 h-4 text-emerald-400" />
                -{avgSorenessRelief} pts Relief
              </span>
            </div>

            <div className="mt-3 space-y-2 text-xs text-[#d0c2df]">
              <p>
                Average reduction in muscular fatigue and joint tightness measured immediately after dedicated recovery circuits.
              </p>
              <div className="p-2.5 rounded-lg bg-[#1a0e28] border border-[#2f1a45] flex items-center justify-between text-[11px]">
                <span className="font-semibold text-emerald-300">Top Modality for Legs & Back:</span>
                <span className="text-[#a597b4] font-medium">HydroMassage Bed (10 Mins)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WORKOUTS HISTORY LOG */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white">
        <div className="flex items-center justify-between pb-3 border-b border-[#2d1942]">
          <div>
            <h3 className="text-base font-bold text-white">Logged Gym Workouts</h3>
            <p className="text-xs text-[#a597b4]">
              Comprehensive log of cardio progressions, resistance circuit weights, and rest recovery.
            </p>
          </div>
          <span className="text-xs font-semibold text-pf-yellow bg-[#25153b] border border-[#381f54] px-2.5 py-1 rounded-lg">
            {workouts.length} Sessions
          </span>
        </div>

        <div className="mt-4 space-y-3">
          {workouts.length === 0 ? (
            <div className="text-center py-8 text-[#8e7e9f] text-xs">
              No workouts logged yet. Complete an Active Gym session to see full breakdown.
            </div>
          ) : (
            workouts.map((workout) => {
              const isExpanded = expandedWorkoutId === workout.id;

              return (
                <div
                  key={workout.id}
                  id={`workout-item-${workout.id}`}
                  className="rounded-xl border border-[#2d1942] overflow-hidden transition-all bg-[#1a0e28]"
                >
                  {/* Summary Bar */}
                  <div
                    onClick={() => setExpandedWorkoutId(isExpanded ? null : workout.id)}
                    className="p-4 bg-[#1a0e28] hover:bg-[#201233] cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#25153b] text-pf-yellow flex items-center justify-center font-bold text-xs ring-1 ring-pf-yellow/30">
                        <Calendar className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{formatDate(workout.date)}</span>
                          <span className="text-[11px] px-2 py-0.2 rounded-full font-semibold bg-[#0f241d] text-emerald-300 border border-emerald-800">
                            {workout.totalDurationMinutes} mins total
                          </span>
                        </div>
                        <div className="text-xs text-[#a597b4] mt-0.5 flex flex-wrap items-center gap-3">
                          <span>Cardio: {workout.cardio?.inclinePercent}% Incline @ {workout.cardio?.speedMph} mph</span>
                          <span>•</span>
                          <span>Rest Tracked: {Math.round((workout.totalRestRecoverySeconds || 0) / 60)} mins</span>
                          {workout.totalVolumeLbs ? (
                            <>
                              <span>•</span>
                              <span className="font-semibold text-pf-yellow font-mono">
                                Vol: {workout.totalVolumeLbs.toLocaleString()} lbs
                              </span>
                            </>
                          ) : null}
                          {workout.readiness ? (
                            <>
                              <span>•</span>
                              <span className="font-semibold text-purple-300">
                                Readiness: {workout.readiness.readinessScore}% ({workout.readiness.status})
                              </span>
                            </>
                          ) : null}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 justify-between sm:justify-end">
                      <div className="text-right">
                        <span className="text-[10px] text-[#8e7e9f] font-semibold uppercase block">
                          Avg Intensity
                        </span>
                        <span className="text-sm font-extrabold text-pf-yellow font-mono">
                          RPE {workout.averageRpe || 5.2}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteWorkout(workout.id);
                        }}
                        className="p-1.5 text-[#8e7e9f] hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                        title="Delete log"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>

                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5 text-[#8e7e9f]" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-[#8e7e9f]" />
                      )}
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="p-4 bg-[#140b20] border-t border-[#2d1942] space-y-4 text-xs">
                      {/* Cardio Summary */}
                      <div className="p-3 bg-[#1a0e28] rounded-xl border border-[#2f1a45]">
                        <div className="font-bold text-white mb-1">Incline Treadmill Progression</div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[#a597b4]">
                          <div>Incline: <span className="font-semibold text-white">{workout.cardio?.inclinePercent}%</span></div>
                          <div>Speed: <span className="font-semibold text-white">{workout.cardio?.speedMph} mph</span></div>
                          <div>Cardio Time: <span className="font-semibold text-white">{workout.cardio?.actualDurationMinutes} mins</span></div>
                          <div>Intensity: <span className="font-semibold text-pf-yellow">RPE {workout.cardio?.actualRpe}</span></div>
                        </div>
                      </div>

                      {/* Exercises Details Table */}
                      <div>
                        <div className="font-bold text-white mb-2">Resistance Circuit Performance</div>
                        <div className="space-y-2">
                          {workout.exercises?.map((ex) => (
                            <div key={ex.exerciseId} className="border border-[#2f1a45] rounded-lg p-2.5 bg-[#1a0e28]">
                              <div className="font-semibold text-white text-xs mb-1.5 flex justify-between">
                                <span>{ex.name}</span>
                                <span className="text-[#8e7e9f] text-[11px]">{ex.keyFocus}</span>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {ex.sets?.map((s) => (
                                   <div
                                    key={s.id}
                                    className="px-2 py-1 bg-[#140b20] border border-[#381f54] text-[#d0c2df] rounded text-[11px] font-mono"
                                  >
                                    Set {s.setNumber}: <span className="font-bold text-pf-yellow">{s.weightLbs} lbs</span> x {s.actualReps} reps • RPE {s.rpe}
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Notes and Recovery */}
                      {workout.notes && (
                        <div className="p-3 bg-[#1f1330] rounded-xl border border-[#381f54] text-[#d0c2df]">
                          <span className="font-semibold text-pf-yellow">Session Notes:</span> {workout.notes}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* DEDICATED SPA RECOVERY DAYS LOG */}
      <div className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm text-white">
        <div className="flex items-center justify-between pb-3 border-b border-[#2d1942]">
          <div>
            <h3 className="text-base font-bold text-white">Logged Spa & Rest Recovery Days</h3>
            <p className="text-xs text-[#a597b4]">
              Sessions dedicated to thermal contrast, red-light circulation, and HydroMassage therapy.
            </p>
          </div>
          <span className="text-xs font-semibold text-pf-yellow bg-[#25153b] border border-[#381f54] px-2.5 py-1 rounded-lg">
            {spaSessions.length} Recovery Days
          </span>
        </div>

        <div className="mt-4 space-y-3">
          {spaSessions.length === 0 ? (
            <div className="text-center py-6 text-[#8e7e9f] text-xs">
              No dedicated recovery sessions logged yet.
            </div>
          ) : (
            spaSessions.map((session) => (
              <div
                key={session.id}
                className="p-4 bg-[#1a0e28] rounded-xl border border-[#2f1a45] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-white text-sm">{formatDate(session.date)}</div>
                  <div className="text-[#a597b4] mt-1 flex flex-wrap gap-2">
                    {session.amenities
                      .filter((a) => a.completed)
                      .map((a) => (
                        <span
                          key={a.amenityId}
                          className="inline-flex items-center px-2 py-0.5 rounded bg-[#25153b] text-pf-yellow font-medium text-[11px] border border-[#381f54]"
                        >
                          {a.name} ({a.durationMinutes}m)
                        </span>
                      ))}
                  </div>
                  {session.notes && <p className="text-[#d0c2df] mt-1.5 italic">"{session.notes}"</p>}
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] text-[#8e7e9f] font-semibold uppercase block">Total Time</span>
                  <span className="text-base font-extrabold text-pf-yellow font-mono">
                    {session.totalDurationMinutes} Mins
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
