import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Clock,
  Flame,
  ShieldCheck,
  Plus,
  Minus,
  Sparkles,
  Info,
  Timer as TimerIcon,
  Layers,
  HeartPulse,
  Dumbbell,
  Headphones,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  CardioSessionLog,
  CustomGoals,
  ExerciseSessionLog,
  ProgressionTier,
  ReadinessCheck,
  ProgressiveOverloadSuggestion,
  TreadmillOverloadSuggestion,
  WorkoutSession,
} from '../types';
import { DEFAULT_EXERCISES, TREADMILL_TIERS } from '../data/protocolDefaults';
import { RestTimerModal } from './RestTimerModal';
import { TempoMetronome } from './TempoMetronome';
import { ReadinessCheckWidget } from './ReadinessCheckWidget';
import { ProgressiveOverloadBanner } from './ProgressiveOverloadBanner';
import { detectProgressiveOverload, calculateSessionVolume } from '../utils/progression';
import { playChime } from '../utils/audio';

interface ActiveGymWorkoutProps {
  customGoals: CustomGoals;
  pastWorkouts?: WorkoutSession[];
  onSaveWorkout: (session: WorkoutSession) => void;
  onNavigateToAnalytics: () => void;
  onUpdateGoals?: (goals: CustomGoals) => void;
  onTriggerMusic?: (category: 'cardio' | 'strength' | 'recovery' | 'focus') => void;
}

export const ActiveGymWorkout: React.FC<ActiveGymWorkoutProps> = ({
  customGoals,
  pastWorkouts = [],
  onSaveWorkout,
  onNavigateToAnalytics,
  onUpdateGoals,
  onTriggerMusic,
}) => {
  // Session global timer
  const [workoutElapsedSeconds, setWorkoutElapsedSeconds] = useState(0);
  const [isSessionActive, setIsSessionActive] = useState(true);

  // Recovery Readiness Assessment
  const [readiness, setReadiness] = useState<ReadinessCheck | undefined>(undefined);

  // Phase 1: Pre-workout Prep
  const [prepLevel, setPrepLevel] = useState<number>(1);
  const [prepSecondsRemaining, setPrepSecondsRemaining] = useState<number>(12 * 60);
  const [isPrepTimerRunning, setIsPrepTimerRunning] = useState<boolean>(false);
  const [prepCompleted, setPrepCompleted] = useState<boolean>(false);

  // Phase 2: Treadmill Progression
  const [progressionTier, setProgressionTier] = useState<ProgressionTier>(customGoals.progressionTier || 'weeks_1_2');
  const [cardioElapsedSeconds, setCardioElapsedSeconds] = useState<number>(0);
  const [isCardioTimerRunning, setIsCardioTimerRunning] = useState<boolean>(false);
  const [cardioIncline, setCardioIncline] = useState<number>(() => {
    if (customGoals.progressionTier === 'custom') return customGoals.customCardioIncline;
    return TREADMILL_TIERS[customGoals.progressionTier]?.inclineMin || 4.0;
  });
  const [cardioSpeed, setCardioSpeed] = useState<number>(() => {
    if (customGoals.progressionTier === 'custom') return customGoals.customCardioSpeed;
    return TREADMILL_TIERS[customGoals.progressionTier]?.speedMin || 2.2;
  });
  const [cardioRpe, setCardioRpe] = useState<number>(5);
  const [cardioCoolDown, setCardioCoolDown] = useState<boolean>(false);
  const [cardioCompleted, setCardioCompleted] = useState<boolean>(false);

  // Phase 3: Resistance Circuit
  const [exercises, setExercises] = useState<ExerciseSessionLog[]>(() => {
    return DEFAULT_EXERCISES.map((def) => {
      const target = customGoals.exerciseTargets[def.id] || {
        targetWeightLbs: def.defaultWeight,
        targetReps: 12,
        targetSets: def.defaultSets,
      };

      const sets = Array.from({ length: target.targetSets }, (_, i) => ({
        id: `${def.id}-set-${i + 1}`,
        setNumber: i + 1,
        targetReps: `${target.targetReps}`,
        actualReps: target.targetReps,
        weightLbs: target.targetWeightLbs,
        rpe: 5,
        completed: false,
        restDurationSeconds: def.suggestedRestSeconds || customGoals.defaultRestTimerSeconds,
      }));

      return {
        exerciseId: def.id,
        name: def.name,
        keyFocus: def.keyFocus,
        sets,
      };
    });
  });

  // Phase 4: Post-Workout HydroMassage
  const [hydroSecondsRemaining, setHydroSecondsRemaining] = useState<number>(10 * 60);
  const [isHydroTimerRunning, setIsHydroTimerRunning] = useState<boolean>(false);
  const [hydroCompleted, setHydroCompleted] = useState<boolean>(false);

  // Progressive Overload Analysis
  const { exerciseSuggestions, treadmillSuggestion } = detectProgressiveOverload(pastWorkouts, customGoals);

  const handleApplyReadiness = (assessment: ReadinessCheck) => {
    setReadiness(assessment);
    setCurrentRestTargetSeconds(assessment.recommendedRestSeconds);
  };

  const handleApplyExerciseOverload = (sug: ProgressiveOverloadSuggestion) => {
    setExercises((prev) =>
      prev.map((ex) => {
        if (ex.exerciseId === sug.exerciseId) {
          return {
            ...ex,
            sets: ex.sets.map((s) => ({
              ...s,
              weightLbs: sug.suggestedWeightLbs,
            })),
          };
        }
        return ex;
      })
    );

    if (onUpdateGoals) {
      onUpdateGoals({
        ...customGoals,
        exerciseTargets: {
          ...customGoals.exerciseTargets,
          [sug.exerciseId]: {
            ...(customGoals.exerciseTargets[sug.exerciseId] || { targetWeightLbs: sug.suggestedWeightLbs, targetReps: 12, targetSets: 3 }),
            targetWeightLbs: sug.suggestedWeightLbs,
          },
        },
      });
    }
  };

  const handleApplyAllOverloads = () => {
    exerciseSuggestions.forEach(handleApplyExerciseOverload);
  };

  const handleApplyTreadmillOverload = (sug: TreadmillOverloadSuggestion) => {
    setProgressionTier(sug.suggestedTier);
    setCardioIncline(sug.suggestedIncline);
    setCardioSpeed(sug.suggestedSpeed);
    if (onUpdateGoals) {
      onUpdateGoals({
        ...customGoals,
        progressionTier: sug.suggestedTier,
        customCardioIncline: sug.suggestedIncline,
        customCardioSpeed: sug.suggestedSpeed,
      });
    }
  };

  // Active Rest Recovery Timer Modal
  const [restModalOpen, setRestModalOpen] = useState(false);
  const [currentRestTargetSeconds, setCurrentRestTargetSeconds] = useState(customGoals.defaultRestTimerSeconds);
  const [lastCompletedExerciseName, setLastCompletedExerciseName] = useState('');
  const [lastCompletedSetNumber, setLastCompletedSetNumber] = useState<number | undefined>(undefined);
  const [totalRestRecoverySeconds, setTotalRestRecoverySeconds] = useState(0);

  // Session timer ticker
  useEffect(() => {
    if (!isSessionActive) return;
    const interval = setInterval(() => {
      setWorkoutElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isSessionActive]);

  // Phase 1 prep countdown
  useEffect(() => {
    if (!isPrepTimerRunning) return;
    const interval = setInterval(() => {
      setPrepSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsPrepTimerRunning(false);
          setPrepCompleted(true);
          playChime('success');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isPrepTimerRunning]);

  // Phase 2 cardio ticker
  useEffect(() => {
    if (!isCardioTimerRunning) return;
    const interval = setInterval(() => {
      setCardioElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isCardioTimerRunning]);

  // Phase 4 hydro countdown
  useEffect(() => {
    if (!isHydroTimerRunning) return;
    const interval = setInterval(() => {
      setHydroSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsHydroTimerRunning(false);
          setHydroCompleted(true);
          playChime('success');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isHydroTimerRunning]);

  // Format mm:ss
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Calculate live average RPE across completed exercises and cardio
  const calculateAverageRpe = () => {
    const rpeValues: number[] = [];
    if (cardioCompleted || cardioElapsedSeconds > 60) {
      rpeValues.push(cardioRpe);
    }
    exercises.forEach((ex) => {
      ex.sets.forEach((set) => {
        if (set.completed) {
          rpeValues.push(set.rpe);
        }
      });
    });

    if (rpeValues.length === 0) return 5.0;
    const sum = rpeValues.reduce((a, b) => a + b, 0);
    return parseFloat((sum / rpeValues.length).toFixed(1));
  };

  const currentAverageRpe = calculateAverageRpe();

  // Completed sets count
  const totalSetsCount = exercises.reduce((acc, ex) => acc + ex.sets.length, 0);
  const completedSetsCount = exercises.reduce(
    (acc, ex) => acc + ex.sets.filter((s) => s.completed).length,
    0
  );

  // Handle set completion
  const handleToggleSetComplete = (exerciseIndex: number, setIndex: number) => {
    const updated = [...exercises];
    const targetSet = updated[exerciseIndex].sets[setIndex];
    const nextStatus = !targetSet.completed;
    targetSet.completed = nextStatus;
    setExercises(updated);

    if (nextStatus) {
      // Trigger rest timer
      setLastCompletedExerciseName(updated[exerciseIndex].name);
      setLastCompletedSetNumber(targetSet.setNumber);
      setCurrentRestTargetSeconds(targetSet.restDurationSeconds || customGoals.defaultRestTimerSeconds);
      setRestModalOpen(true);
    }
  };

  const handleUpdateSet = (
    exerciseIndex: number,
    setIndex: number,
    field: 'weightLbs' | 'actualReps' | 'rpe' | 'restDurationSeconds',
    value: number
  ) => {
    const updated = [...exercises];
    updated[exerciseIndex].sets[setIndex] = {
      ...updated[exerciseIndex].sets[setIndex],
      [field]: value,
    };
    setExercises(updated);
  };

  const handleRestCompleted = (elapsedSeconds: number) => {
    setTotalRestRecoverySeconds((prev) => prev + elapsedSeconds);
  };

  const handleFinishWorkout = () => {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {}

    const cardioLog: CardioSessionLog = {
      inclinePercent: cardioIncline,
      speedMph: cardioSpeed,
      targetDurationMinutes: Math.round(cardioElapsedSeconds / 60) || 15,
      actualDurationMinutes: Math.max(1, Math.round(cardioElapsedSeconds / 60)),
      targetRpe: TREADMILL_TIERS[progressionTier]?.targetRpe || 'RPE 4–6',
      actualRpe: cardioRpe,
      coolDownCompleted: cardioCoolDown,
      notes: `Incline ${cardioIncline}%, Speed ${cardioSpeed} mph. Cool down: ${cardioCoolDown ? 'Yes' : 'No'}`,
    };

    const totalVolume = exercises.reduce((total, ex) => {
      return total + ex.sets.reduce((sum, s) => (s.completed ? sum + s.weightLbs * s.actualReps : sum), 0);
    }, 0);

    const session: WorkoutSession = {
      id: `workout-${Date.now()}`,
      date: new Date().toISOString(),
      totalDurationMinutes: Math.max(1, Math.round(workoutElapsedSeconds / 60)),
      preWorkoutPrepMinutes: Math.round((12 * 60 - prepSecondsRemaining) / 60) || (prepCompleted ? 12 : 0),
      prepCompleted,
      prepLevel,
      cardio: cardioLog,
      exercises,
      postWorkoutHydroMinutes: Math.round((10 * 60 - hydroSecondsRemaining) / 60) || (hydroCompleted ? 10 : 0),
      postWorkoutCompleted: hydroCompleted,
      totalRestRecoverySeconds,
      averageRpe: currentAverageRpe,
      totalVolumeLbs: totalVolume,
      readiness,
      notes: `Completed ${completedSetsCount}/${totalSetsCount} resistance sets. Volume lifted: ${totalVolume.toLocaleString()} lbs. Active rest tracked: ${Math.round(
        totalRestRecoverySeconds / 60
      )} min. Average workout intensity: RPE ${currentAverageRpe}.`,
    };

    onSaveWorkout(session);
    playChime('success');
    onNavigateToAnalytics();
  };

  const tierInfo = TREADMILL_TIERS[progressionTier];
  const liveVolumeLbs = exercises.reduce((total, ex) => {
    return total + ex.sets.reduce((sum, s) => (s.completed ? sum + s.weightLbs * s.actualReps : sum), 0);
  }, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Session Header Bar */}
      <div
        id="active-session-header"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-white"
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-black bg-pf-yellow text-pf-purple-deep shadow-2xs">
              Active Gym Routine
            </span>
            <span className="text-xs text-[#a597b4] font-bold">Mon / Wed / Fri Split</span>
          </div>
          <h2 className="text-xl font-extrabold text-white mt-1">Gym Day Intensity & Recovery Session</h2>
          <p className="text-xs text-[#a597b4] mt-0.5">
            Cardio baseline progression, machine resistance circuit, and active recovery periods.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Workout Elapsed Timer */}
          <div className="flex items-center gap-2 bg-[#1f1330] border border-[#381f54] px-3.5 py-2 rounded-xl text-xs">
            <Clock className="w-4 h-4 text-pf-yellow" />
            <div>
              <div className="text-[10px] text-[#8e7e9f] font-semibold uppercase">Total Time</div>
              <div className="font-mono font-bold text-white text-sm">{formatTimer(workoutElapsedSeconds)}</div>
            </div>
          </div>

          {/* Total Recovery Time Logged */}
          <div className="flex items-center gap-2 bg-[#0d221a] border border-[#164a38] px-3.5 py-2 rounded-xl text-xs">
            <TimerIcon className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-[10px] text-emerald-400/80 font-semibold uppercase">Rest Tracked</div>
              <div className="font-mono font-bold text-emerald-300 text-sm">
                {Math.floor(totalRestRecoverySeconds / 60)}m {totalRestRecoverySeconds % 60}s
              </div>
            </div>
          </div>

          {/* Live Volume Lifted */}
          <div className="flex items-center gap-2 bg-[#24133b] border border-[#3f2263] px-3.5 py-2 rounded-xl text-xs">
            <Dumbbell className="w-4 h-4 text-pf-yellow" />
            <div>
              <div className="text-[10px] text-pf-yellow/80 font-bold uppercase">Volume Lifted</div>
              <div className="font-mono font-extrabold text-white text-sm">
                {liveVolumeLbs.toLocaleString()} lbs
              </div>
            </div>
          </div>

          {/* Average RPE Gauge */}
          <div className="flex items-center gap-2 bg-[#121e36] border border-[#1d355f] px-3.5 py-2 rounded-xl text-xs">
            <HeartPulse className="w-4 h-4 text-blue-400" />
            <div>
              <div className="text-[10px] text-blue-300/80 font-semibold uppercase">Average Intensity</div>
              <div className="font-bold text-blue-200 text-sm flex items-center gap-1">
                RPE {currentAverageRpe}
                <span className="text-[10px] font-normal text-blue-300">
                  {currentAverageRpe >= 4 && currentAverageRpe <= 6 ? '(Target Zone)' : ''}
                </span>
              </div>
            </div>
          </div>

          {/* Finish & Save Workout */}
          <button
            id="finish-save-workout-btn"
            type="button"
            onClick={handleFinishWorkout}
            className="ml-auto md:ml-0 flex items-center gap-2 bg-pf-purple hover:bg-pf-purple-light text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all cursor-pointer ring-2 ring-pf-yellow/60"
          >
            <CheckCircle2 className="w-4 h-4 text-pf-yellow" />
            Save & Finish Session
          </button>
        </div>
      </div>

      {/* Pre-Workout Recovery Readiness Check */}
      <ReadinessCheckWidget
        currentReadiness={readiness}
        onApplyReadiness={handleApplyReadiness}
      />

      {/* PHASE 1: Pre-Workout Prep (12 Mins) */}
      <div
        id="phase-1-card"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm transition-all hover:border-[#422562] text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-pf-purple text-pf-yellow font-extrabold text-sm flex items-center justify-center shadow-xs ring-1 ring-pf-yellow/40">
              1
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">Phase 1: Pre-Workout Prep</h3>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#24133b] text-pf-yellow border border-[#3f2263]">
                  12 Mins
                </span>
              </div>
              <p className="text-xs text-[#a597b4]">
                Total Body Enhancement (Black Card®): Preps joints & increases skin circulation before loading.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-[#a597b4] font-medium">Intensity Level:</span>
            <div className="inline-flex rounded-lg border border-[#381f54] p-0.5 bg-[#1e1130] text-xs">
              <button
                type="button"
                onClick={() => setPrepLevel(1)}
                className={`px-2.5 py-1 rounded-md font-bold transition-colors ${
                  prepLevel === 1 ? 'bg-pf-purple text-pf-yellow shadow-xs' : 'text-[#a597b4] hover:text-white'
                }`}
              >
                Level 1
              </button>
              <button
                type="button"
                onClick={() => setPrepLevel(2)}
                className={`px-2.5 py-1 rounded-md font-bold transition-colors ${
                  prepLevel === 2 ? 'bg-pf-purple text-pf-yellow shadow-xs' : 'text-[#a597b4] hover:text-white'
                }`}
              >
                Level 2
              </button>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#1f1231] p-4 rounded-xl border border-[#381f54]">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full border-4 border-pf-purple/30 border-t-pf-yellow flex items-center justify-center font-mono font-extrabold text-white text-base">
              {formatTimer(prepSecondsRemaining)}
            </div>
            <div>
              <div className="text-xs font-bold text-white">Circulation & Warm-up Countdown</div>
              <p className="text-xs text-[#a597b4]">
                Gentle red-light and vibration frequency helps warm connective tissue.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              id="prep-timer-toggle-btn"
              type="button"
              onClick={() => setIsPrepTimerRunning(!isPrepTimerRunning)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isPrepTimerRunning
                  ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs'
                  : 'bg-pf-purple hover:bg-pf-purple-light text-white shadow-xs ring-1 ring-pf-yellow/40'
              }`}
            >
              {isPrepTimerRunning ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              {isPrepTimerRunning ? 'Pause Prep' : 'Start 12m Prep'}
            </button>

            <button
              id="prep-timer-reset-btn"
              type="button"
              onClick={() => {
                setIsPrepTimerRunning(false);
                setPrepSecondsRemaining(12 * 60);
              }}
              className="p-2 rounded-xl border border-[#381f54] text-[#a597b4] hover:bg-[#25153b] hover:text-white"
              title="Reset 12m timer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              id="prep-complete-toggle-btn"
              type="button"
              onClick={() => setPrepCompleted(!prepCompleted)}
              className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                prepCompleted
                  ? 'bg-[#0f241d] border-emerald-600 text-emerald-300'
                  : 'bg-[#1f1231] border-[#381f54] text-[#a597b4] hover:bg-[#281740] hover:text-white'
              }`}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${prepCompleted ? 'text-emerald-400' : 'text-[#7e6e91]'}`} />
              {prepCompleted ? 'Prep Done' : 'Mark Done'}
            </button>
          </div>
        </div>
      </div>

      {/* PHASE 2: Incline Treadmill Progression (15–20 Mins) */}
      <div
        id="phase-2-card"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm transition-all hover:border-[#422562] text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-pf-purple text-pf-yellow font-extrabold text-sm flex items-center justify-center shadow-xs ring-1 ring-pf-yellow/40">
              2
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">Phase 2: Incline Treadmill Progression</h3>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#24133b] text-pf-yellow border border-[#3f2263]">
                  15–20 Mins
                </span>
              </div>
              <p className="text-xs text-[#a597b4]">
                Cardio baseline progression tracking intensity, incline, speed, and perceived effort.
              </p>
            </div>
          </div>

          {/* Progression Stage Picker */}
          <div className="flex flex-wrap items-center gap-2">
            {onTriggerMusic && (
              <button
                id="cardio-music-trigger-btn"
                type="button"
                onClick={() => onTriggerMusic('cardio')}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold bg-[#1e1130] text-pf-yellow border border-[#381f54] hover:bg-pf-yellow hover:text-pf-purple-deep transition-all cursor-pointer shadow-2xs"
                title="Launch Cardio Music (Spotify / YouTube Music)"
              >
                <Headphones className="w-3.5 h-3.5 text-pf-yellow" />
                <span>Cardio Music</span>
              </button>
            )}

            <div className="flex items-center gap-1.5">
              <span className="text-xs text-[#a597b4] font-medium">Stage:</span>
              <select
                id="treadmill-tier-select"
                value={progressionTier}
                onChange={(e) => {
                  const val = e.target.value as ProgressionTier;
                  setProgressionTier(val);
                  if (val !== 'custom') {
                    setCardioIncline(TREADMILL_TIERS[val].inclineMin);
                    setCardioSpeed(TREADMILL_TIERS[val].speedMin);
                  }
                }}
                className="text-xs font-semibold bg-[#1e1130] border border-[#381f54] rounded-lg px-2.5 py-1 text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
              >
                <option value="weeks_1_2">Weeks 1–2 (3.0%–5.0%, 2.0–2.5 mph)</option>
                <option value="weeks_3_4">Weeks 3–4 (6.0%–8.0%, 2.0–2.3 mph)</option>
                <option value="weeks_5_6_plus">Weeks 5–6+ (10.0%–12.0%+, 1.8–2.0 mph)</option>
                <option value="custom">Custom Goal Target</option>
              </select>
            </div>
          </div>
        </div>

        {/* Prescription Target Callout & Protocol Handrail Rule */}
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 bg-[#24133b] rounded-xl border border-[#3f2263] flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-pf-yellow shrink-0 mt-0.5" />
            <div className="text-xs">
              <div className="font-bold text-white">Target Protocol</div>
              <div className="text-[#d8c8ea] mt-0.5">
                Incline: <span className="font-extrabold text-pf-yellow">{tierInfo.inclineMin}% – {tierInfo.inclineMax}%</span> | Speed:{' '}
                <span className="font-extrabold text-pf-yellow">{tierInfo.speedMin} – {tierInfo.speedMax} mph</span>
              </div>
              <div className="text-[#b19fc4] font-medium text-[11px] mt-0.5">Target Intensity: {tierInfo.targetRpe}</div>
            </div>
          </div>

          <div className="p-3 bg-[#231505] rounded-xl border border-[#52330a] flex items-start gap-2.5">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <div className="font-semibold text-amber-200">Strict Form Rule</div>
              <div className="text-amber-300/80 mt-0.5">
                <span className="font-bold text-amber-200">Never hold handrails.</span> Swing arms naturally to stabilize your core
                and drive posterior chain engagement.
              </div>
            </div>
          </div>

          <div className="p-3 bg-[#0d221a] rounded-xl border border-[#164a38] flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <div className="font-semibold text-emerald-200">Cool Down Protocol</div>
              <div className="text-emerald-300/80 mt-0.5">
                Cool down at <span className="font-bold text-emerald-200">0.0% incline / 1.5 mph</span> for 2–3 mins before stepping off.
              </div>
            </div>
          </div>
        </div>

        {/* Live Cardio Logger Controls */}
        <div className="mt-4 bg-[#1a0e28] p-4 rounded-xl border border-[#2f1a45]">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Live Cardio Timer */}
            <div className="bg-[#140b20] p-3 rounded-lg border border-[#2c1740] shadow-2xs">
              <div className="flex items-center justify-between text-xs text-[#a597b4] mb-1">
                <span className="font-medium text-[#d0c2df]">Cardio Duration</span>
                <span className="text-[10px] text-[#8e7e9f]">Target 15–20m</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-2xl text-white">{formatTimer(cardioElapsedSeconds)}</span>
                <button
                  id="cardio-timer-toggle-btn"
                  type="button"
                  onClick={() => setIsCardioTimerRunning(!isCardioTimerRunning)}
                  className={`p-2 rounded-lg text-xs font-semibold ${
                    isCardioTimerRunning ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'bg-pf-purple hover:bg-pf-purple-light text-white ring-1 ring-pf-yellow/40'
                  }`}
                  title={isCardioTimerRunning ? 'Pause timer' : 'Start treadmill timer'}
                >
                  {isCardioTimerRunning ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current text-pf-yellow" />}
                </button>
              </div>
            </div>

            {/* Incline Input */}
            <div className="bg-[#140b20] p-3 rounded-lg border border-[#2c1740] shadow-2xs">
              <div className="flex items-center justify-between text-xs text-[#a597b4] mb-1">
                <span className="font-medium text-[#d0c2df]">Incline %</span>
                <span className="text-[10px] text-pf-yellow font-semibold">{tierInfo.inclineMin}–{tierInfo.inclineMax}%</span>
              </div>
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setCardioIncline((prev) => Math.max(0, +(prev - 0.5).toFixed(1)))}
                  className="w-8 h-8 rounded-md bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <div className="flex items-baseline gap-0.5">
                  <span className="text-2xl font-bold text-pf-yellow font-mono">{cardioIncline.toFixed(1)}</span>
                  <span className="text-xs text-[#a597b4] font-semibold">%</span>
                </div>
                <button
                  type="button"
                  onClick={() => setCardioIncline((prev) => +(prev + 0.5).toFixed(1))}
                  className="w-8 h-8 rounded-md bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Speed Input */}
            <div className="bg-[#140b20] p-3 rounded-lg border border-[#2c1740] shadow-2xs">
              <div className="flex items-center justify-between text-xs text-[#a597b4] mb-1">
                <span className="font-medium text-[#d0c2df]">Speed mph</span>
                <span className="text-[10px] text-pf-yellow font-semibold">{tierInfo.speedMin}–{tierInfo.speedMax} mph</span>
              </div>
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setCardioSpeed((prev) => Math.max(0.5, +(prev - 0.1).toFixed(1)))}
                  className="w-8 h-8 rounded-md bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <div className="flex items-baseline gap-0.5">
                  <span className="text-2xl font-bold text-pf-yellow font-mono">{cardioSpeed.toFixed(1)}</span>
                  <span className="text-xs text-[#a597b4] font-semibold">mph</span>
                </div>
                <button
                  type="button"
                  onClick={() => setCardioSpeed((prev) => +(prev + 0.1).toFixed(1))}
                  className="w-8 h-8 rounded-md bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* RPE Exertion Rating */}
            <div className="bg-[#140b20] p-3 rounded-lg border border-[#2c1740] shadow-2xs flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-[#a597b4]">
                <span className="font-medium text-[#d0c2df]">Workout Intensity</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                    cardioRpe >= 4 && cardioRpe <= 6
                      ? 'bg-blue-900/60 text-blue-200 border border-blue-700/60'
                      : cardioRpe < 4
                      ? 'bg-emerald-900/60 text-emerald-200 border border-emerald-700/60'
                      : 'bg-amber-900/60 text-amber-200 border border-amber-700/60'
                  }`}
                >
                  {cardioRpe >= 4 && cardioRpe <= 6 ? 'Target Zone' : `RPE ${cardioRpe}`}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <input
                  id="cardio-rpe-slider"
                  type="range"
                  min="1"
                  max="10"
                  value={cardioRpe}
                  onChange={(e) => setCardioRpe(Number(e.target.value))}
                  className="w-full accent-pf-yellow h-2 bg-[#2c1844] rounded-lg cursor-pointer"
                />
                <span className="text-base font-extrabold text-pf-yellow font-mono w-6 text-right">{cardioRpe}</span>
              </div>
              <span className="text-[10px] text-[#8e7e9f]">Target Effort: RPE 4–6</span>
            </div>
          </div>

          {/* Cool down and completion checks */}
          <div className="mt-3 pt-3 border-t border-[#2f1a45] flex flex-wrap items-center justify-between gap-3 text-xs">
            <label className="flex items-center gap-2 text-[#d0c2df] cursor-pointer select-none">
              <input
                id="cool-down-checkbox"
                type="checkbox"
                checked={cardioCoolDown}
                onChange={(e) => setCardioCoolDown(e.target.checked)}
                className="w-4 h-4 rounded accent-pf-yellow text-pf-yellow"
              />
              <span>Completed 2–3 min cool down (0.0% incline / 1.5 mph)</span>
            </label>

            <button
              id="mark-cardio-complete-btn"
              type="button"
              onClick={() => {
                setCardioCompleted(!cardioCompleted);
                if (!cardioCompleted && isCardioTimerRunning) {
                  setIsCardioTimerRunning(false);
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                cardioCompleted
                  ? 'bg-[#0f241d] text-emerald-300 border border-emerald-600'
                  : 'bg-[#201235] text-white border border-[#381f54] hover:bg-[#2c1845]'
              }`}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${cardioCompleted ? 'text-emerald-400' : 'text-[#7e6e91]'}`} />
              {cardioCompleted ? 'Cardio Logged' : 'Mark Cardio Complete'}
            </button>
          </div>
        </div>
      </div>

      {/* Adaptive Progressive Overload Recommendations */}
      <ProgressiveOverloadBanner
        exerciseSuggestions={exerciseSuggestions}
        treadmillSuggestion={treadmillSuggestion}
        onApplyExerciseOverload={handleApplyExerciseOverload}
        onApplyAllOverloads={handleApplyAllOverloads}
        onApplyTreadmillOverload={handleApplyTreadmillOverload}
      />

      {/* PHASE 3: Machine Resistance Circuit */}
      <div
        id="phase-3-card"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm transition-all hover:border-[#422562] text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-pf-purple text-pf-yellow font-extrabold text-sm flex items-center justify-center shadow-xs ring-1 ring-pf-yellow/40">
              3
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">Phase 3: Machine Resistance Circuit</h3>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#24133b] text-pf-yellow border border-[#3f2263]">
                  {completedSetsCount}/{totalSetsCount} Sets Done
                </span>
              </div>
              <p className="text-xs text-[#a597b4]">
                Straight sets (60–90s rest). Controlled 2s out / 2s back tempo.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onTriggerMusic && (
              <button
                id="lifting-music-trigger-btn"
                type="button"
                onClick={() => onTriggerMusic('strength')}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold bg-[#1e1130] text-pf-yellow border border-[#381f54] hover:bg-pf-yellow hover:text-pf-purple-deep transition-all cursor-pointer shadow-2xs"
                title="Launch Heavy Lifting Music (Bass & Rock)"
              >
                <Headphones className="w-3.5 h-3.5 text-pf-yellow" />
                <span>Lifting Music</span>
              </button>
            )}

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#a597b4] font-medium">Default Rest:</span>
              <select
                id="default-rest-selector"
                value={currentRestTargetSeconds}
                onChange={(e) => setCurrentRestTargetSeconds(Number(e.target.value))}
                className="text-xs font-semibold bg-[#1e1130] border border-[#381f54] rounded-lg px-2.5 py-1 text-white focus:outline-hidden focus:ring-1 focus:ring-pf-yellow"
              >
                <option value="60">60s (Core / Quick)</option>
                <option value="75">75s (Standard)</option>
                <option value="90">90s (Heavy Leg Press)</option>
                <option value="120">120s (Extended)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Tempo Metronome Helper */}
        <div className="mt-4">
          <TempoMetronome />
        </div>

        {/* Exercises List */}
        <div className="mt-4 space-y-4">
          {exercises.map((exercise, exIdx) => {
            const allSetsCompleted = exercise.sets.every((s) => s.completed);

            return (
              <div
                key={exercise.exerciseId}
                id={`exercise-card-${exercise.exerciseId}`}
                className={`p-4 rounded-xl border transition-all ${
                  allSetsCompleted
                    ? 'bg-[#101b17] border-[#1d4c39]'
                    : 'bg-[#1b1029] border-[#311b49] hover:border-[#4d2974]'
                }`}
              >
                {/* Exercise Title Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 mb-3 border-b border-[#2d1942]">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2.5 h-2.5 rounded-full ${allSetsCompleted ? 'bg-emerald-400' : 'bg-pf-yellow'}`}
                    />
                    <h4 className="font-bold text-white text-sm">{exercise.name}</h4>
                    <span className="text-xs text-[#a597b4] font-medium">• {exercise.sets.length} Sets</span>
                  </div>
                  <div className="text-xs text-[#a597b4] flex items-center gap-1.5">
                    <span className="font-bold text-pf-yellow bg-[#25153c] px-2 py-0.5 rounded-md border border-[#3f2263]">
                      Key Focus: {exercise.keyFocus}
                    </span>
                  </div>
                </div>

                {/* Sets Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="text-[#8a7b9e] font-semibold uppercase text-[10px] tracking-wider border-b border-[#2d1942]">
                        <th className="py-2 px-2 w-12">Set</th>
                        <th className="py-2 px-2 w-28">Weight (lbs)</th>
                        <th className="py-2 px-2 w-28">Reps</th>
                        <th className="py-2 px-2 w-44">Intensity (RPE)</th>
                        <th className="py-2 px-2 w-24">Rest (s)</th>
                        <th className="py-2 px-2 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#24143a]">
                      {exercise.sets.map((set, sIdx) => {
                        return (
                          <tr
                            key={set.id}
                            className={`transition-colors ${set.completed ? 'bg-[#0e241c]/50 text-emerald-200' : 'hover:bg-[#221334]/60 text-[#e2d8ec]'}`}
                          >
                            {/* Set Number */}
                            <td className="py-2.5 px-2 font-bold font-mono text-white">
                              #{set.setNumber}
                            </td>

                            {/* Weight with quick buttons */}
                            <td className="py-2.5 px-2">
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'weightLbs',
                                      Math.max(5, set.weightLbs - 5)
                                    )
                                  }
                                  className="w-5 h-5 rounded bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                                >
                                  -
                                </button>
                                <input
                                  type="number"
                                  value={set.weightLbs}
                                  onChange={(e) =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'weightLbs',
                                      Math.max(0, Number(e.target.value))
                                    )
                                  }
                                  className="w-14 text-center font-mono font-bold bg-[#140b20] border border-[#381f54] rounded py-0.5 px-1 text-white focus:ring-1 focus:ring-pf-yellow"
                                />
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'weightLbs',
                                      set.weightLbs + 5
                                    )
                                  }
                                  className="w-5 h-5 rounded bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                                >
                                  +
                                </button>
                              </div>
                            </td>

                            {/* Reps */}
                            <td className="py-2.5 px-2">
                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'actualReps',
                                      Math.max(1, set.actualReps - 1)
                                    )
                                  }
                                  className="w-5 h-5 rounded bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                                >
                                  -
                                </button>
                                <input
                                  type="number"
                                  value={set.actualReps}
                                  onChange={(e) =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'actualReps',
                                      Math.max(1, Number(e.target.value))
                                    )
                                  }
                                  className="w-10 text-center font-mono font-bold bg-[#140b20] border border-[#381f54] rounded py-0.5 px-1 text-white focus:ring-1 focus:ring-pf-yellow"
                                />
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'actualReps',
                                      set.actualReps + 1
                                    )
                                  }
                                  className="w-5 h-5 rounded bg-[#25153b] hover:bg-[#341d52] text-white flex items-center justify-center font-bold"
                                >
                                  +
                                </button>
                              </div>
                            </td>

                            {/* Set RPE */}
                            <td className="py-2.5 px-2">
                              <div className="flex items-center gap-2">
                                <select
                                  value={set.rpe}
                                  onChange={(e) =>
                                    handleUpdateSet(
                                      exIdx,
                                      sIdx,
                                      'rpe',
                                      Number(e.target.value)
                                    )
                                  }
                                  className={`text-xs font-semibold rounded px-1.5 py-0.5 border ${
                                    set.rpe >= 4 && set.rpe <= 6
                                      ? 'bg-blue-950/70 text-blue-200 border-blue-800'
                                      : set.rpe < 4
                                      ? 'bg-emerald-950/70 text-emerald-200 border-emerald-800'
                                      : 'bg-amber-950/70 text-amber-200 border-amber-800'
                                  }`}
                                >
                                  <option value="3">RPE 3 - Light</option>
                                  <option value="4">RPE 4 - Moderate (Target)</option>
                                  <option value="5">RPE 5 - Target Zone</option>
                                  <option value="6">RPE 6 - Heavy breathing</option>
                                  <option value="7">RPE 7 - Vigorous</option>
                                  <option value="8">RPE 8 - Hard push</option>
                                  <option value="9">RPE 9 - Near max</option>
                                  <option value="10">RPE 10 - Max limit</option>
                                </select>
                              </div>
                            </td>

                            {/* Rest target */}
                            <td className="py-2.5 px-2 font-mono text-[#8e7e9f]">
                              {set.restDurationSeconds}s
                            </td>

                            {/* Complete Button / Trigger Rest */}
                            <td className="py-2.5 px-2 text-right">
                              <button
                                id={`complete-btn-${exercise.exerciseId}-${sIdx}`}
                                type="button"
                                onClick={() => handleToggleSetComplete(exIdx, sIdx)}
                                className={`inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                                  set.completed
                                    ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-2xs'
                                    : 'bg-[#25153b] hover:bg-pf-purple hover:text-pf-yellow text-white border border-[#3b215c]'
                                }`}
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                {set.completed ? 'Done' : 'Complete Set'}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* PHASE 4: Post-Workout Recovery (10 Mins) */}
      <div
        id="phase-4-card"
        className="bg-[#160e22] rounded-2xl border border-[#2d1942] p-5 shadow-sm transition-all hover:border-[#422562] text-white"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-pf-purple text-pf-yellow font-extrabold text-sm flex items-center justify-center shadow-xs ring-1 ring-pf-yellow/40">
              4
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-white">Phase 4: Post-Workout Recovery</h3>
                <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#24133b] text-pf-yellow border border-[#3f2263]">
                  10 Mins
                </span>
              </div>
              <p className="text-xs text-[#a597b4]">
                HydroMassage Bed (Black Card®): Medium pressure. Flushes muscular metabolites and speeds systemic recovery.
              </p>
            </div>
          </div>

          <div className="text-xs text-[#a597b4] font-medium">
            Protocol: <span className="text-pf-yellow font-bold">Medium Pressure</span>
          </div>
        </div>

        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#1f1231] p-4 rounded-xl border border-[#381f54]">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full border-4 border-pf-purple/30 border-t-pf-yellow flex items-center justify-center font-mono font-extrabold text-white text-base">
              {formatTimer(hydroSecondsRemaining)}
            </div>
            <div>
              <div className="text-xs font-bold text-white">HydroMassage Relaxation Countdown</div>
              <p className="text-xs text-[#a597b4]">
                Rule: Stand up slowly after completion to allow circulation equilibrium.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              id="hydro-timer-toggle-btn"
              type="button"
              onClick={() => setIsHydroTimerRunning(!isHydroTimerRunning)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isHydroTimerRunning
                  ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs'
                  : 'bg-pf-purple hover:bg-pf-purple-light text-white shadow-xs ring-1 ring-pf-yellow/40'
              }`}
            >
              {isHydroTimerRunning ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              {isHydroTimerRunning ? 'Pause Massage' : 'Start 10m Massage'}
            </button>

            <button
              id="hydro-timer-reset-btn"
              type="button"
              onClick={() => {
                setIsHydroTimerRunning(false);
                setHydroSecondsRemaining(10 * 60);
              }}
              className="p-2 rounded-xl border border-[#381f54] text-[#a597b4] hover:bg-[#25153b] hover:text-white"
              title="Reset 10m timer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              id="hydro-complete-toggle-btn"
              type="button"
              onClick={() => setHydroCompleted(!hydroCompleted)}
              className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                hydroCompleted
                  ? 'bg-[#0f241d] border-emerald-600 text-emerald-300'
                  : 'bg-[#1f1231] border-[#381f54] text-[#a597b4] hover:bg-[#281740] hover:text-white'
              }`}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${hydroCompleted ? 'text-emerald-400' : 'text-[#7e6e91]'}`} />
              {hydroCompleted ? 'Recovery Done' : 'Mark Done'}
            </button>
          </div>
        </div>
      </div>

      {/* Rest Timer Modal */}
      <RestTimerModal
        isOpen={restModalOpen}
        onClose={() => setRestModalOpen(false)}
        targetSeconds={currentRestTargetSeconds}
        exerciseName={lastCompletedExerciseName}
        setNumber={lastCompletedSetNumber}
        onRestCompleted={handleRestCompleted}
      />
    </div>
  );
};
