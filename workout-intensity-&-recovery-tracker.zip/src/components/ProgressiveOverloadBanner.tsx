import React, { useState } from 'react';
import { TrendingUp, ArrowUpRight, Check, Sparkles, CheckCheck } from 'lucide-react';
import {
  ProgressiveOverloadSuggestion,
  TreadmillOverloadSuggestion,
} from '../types';

interface ProgressiveOverloadBannerProps {
  exerciseSuggestions: ProgressiveOverloadSuggestion[];
  treadmillSuggestion: TreadmillOverloadSuggestion | null;
  onApplyExerciseOverload: (suggestion: ProgressiveOverloadSuggestion) => void;
  onApplyAllOverloads: () => void;
  onApplyTreadmillOverload: (suggestion: TreadmillOverloadSuggestion) => void;
}

export const ProgressiveOverloadBanner: React.FC<ProgressiveOverloadBannerProps> = ({
  exerciseSuggestions,
  treadmillSuggestion,
  onApplyExerciseOverload,
  onApplyAllOverloads,
  onApplyTreadmillOverload,
}) => {
  const [appliedIds, setAppliedIds] = useState<Record<string, boolean>>({});
  const [treadmillApplied, setTreadmillApplied] = useState(false);

  if (exerciseSuggestions.length === 0 && !treadmillSuggestion) {
    return null;
  }

  const handleApplySingle = (sug: ProgressiveOverloadSuggestion) => {
    onApplyExerciseOverload(sug);
    setAppliedIds((prev) => ({ ...prev, [sug.exerciseId]: true }));
  };

  const handleApplyAll = () => {
    onApplyAllOverloads();
    const map: Record<string, boolean> = {};
    exerciseSuggestions.forEach((s) => {
      map[s.exerciseId] = true;
    });
    setAppliedIds(map);
  };

  const handleApplyTreadmill = () => {
    if (!treadmillSuggestion) return;
    onApplyTreadmillOverload(treadmillSuggestion);
    setTreadmillApplied(true);
  };

  const pendingCount = exerciseSuggestions.filter((s) => !appliedIds[s.exerciseId]).length;

  return (
    <div
      id="progressive-overload-banner"
      className="bg-linear-to-r from-pf-purple-dark via-pf-purple-deep to-pf-purple-dark text-white rounded-2xl p-5 shadow-md border border-pf-yellow/40 space-y-4"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-pf-yellow text-pf-purple-deep flex items-center justify-center font-bold shadow-xs">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-extrabold tracking-tight text-white">Adaptive Progressive Overload Detected</h3>
              <span className="text-[10px] font-black uppercase tracking-wider bg-pf-yellow text-pf-purple-deep px-2 py-0.5 rounded-full shadow-2xs">
                RPE Zone Mastered
              </span>
            </div>
            <p className="text-xs text-purple-200 mt-0.5">
              You completed your target sets within RPE 4–6 with sustainable form. Ready to advance resistance!
            </p>
          </div>
        </div>

        {pendingCount > 0 && (
          <button
            id="apply-all-overload-btn"
            type="button"
            onClick={handleApplyAll}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-pf-yellow hover:bg-pf-yellow-hover text-pf-purple-deep text-xs font-black shadow-xs transition-colors self-end sm:self-auto cursor-pointer"
          >
            <CheckCheck className="w-4 h-4" />
            Apply All ({pendingCount}) Increases
          </button>
        )}
      </div>

      {/* Suggested increases list */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {exerciseSuggestions.map((sug) => {
          const isApplied = !!appliedIds[sug.exerciseId];

          return (
            <div
              key={sug.exerciseId}
              className={`p-3 rounded-xl border transition-all flex flex-col justify-between ${
                isApplied
                  ? 'bg-pf-purple/30 border-pf-yellow/40 text-pf-yellow'
                  : 'bg-black/30 border-purple-800/60 text-slate-200 hover:border-pf-yellow/50'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-xs font-bold mb-1">
                  <span>{sug.exerciseName}</span>
                  <span className="font-mono text-purple-200">
                    {sug.currentWeightLbs} → <span className="text-pf-yellow font-black">{sug.suggestedWeightLbs} lbs</span>
                  </span>
                </div>
                <p className="text-[11px] text-purple-200/80 leading-tight mb-2.5">{sug.reason}</p>
              </div>

              <div className="pt-2 border-t border-purple-800/50 flex items-center justify-between">
                <span className="text-[10px] font-bold text-pf-yellow">
                  +{sug.increaseLbs} lbs increase
                </span>
                <button
                  type="button"
                  onClick={() => handleApplySingle(sug)}
                  disabled={isApplied}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors ${
                    isApplied
                      ? 'bg-pf-yellow/20 text-pf-yellow cursor-default'
                      : 'bg-pf-yellow hover:bg-pf-yellow-hover text-pf-purple-deep cursor-pointer'
                  }`}
                >
                  {isApplied ? <Check className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                  {isApplied ? 'Applied' : `Bump to ${sug.suggestedWeightLbs} lbs`}
                </button>
              </div>
            </div>
          );
        })}

        {/* Treadmill Suggestion Card */}
        {treadmillSuggestion && (
          <div
            className={`p-3 rounded-xl border transition-all flex flex-col justify-between ${
              treadmillApplied
                ? 'bg-pf-purple/30 border-pf-yellow/40 text-pf-yellow'
                : 'bg-black/30 border-purple-800/60 text-slate-200 hover:border-pf-yellow/50'
            }`}
          >
            <div>
              <div className="flex items-center justify-between text-xs font-bold mb-1">
                <span>Incline Treadmill Stage</span>
                <span className="font-mono text-pf-yellow font-bold">
                  Tier Advance
                </span>
              </div>
              <p className="text-[11px] text-purple-200/80 leading-tight mb-2.5">{treadmillSuggestion.reason}</p>
            </div>

            <div className="pt-2 border-t border-purple-800/50 flex items-center justify-between">
              <span className="text-[10px] font-bold text-pf-yellow">
                Next Progression Stage
              </span>
              <button
                type="button"
                onClick={handleApplyTreadmill}
                disabled={treadmillApplied}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors ${
                  treadmillApplied
                    ? 'bg-pf-yellow/20 text-pf-yellow cursor-default'
                    : 'bg-pf-yellow hover:bg-pf-yellow-hover text-pf-purple-deep cursor-pointer'
                }`}
              >
                {treadmillApplied ? <Check className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                {treadmillApplied ? 'Applied' : 'Advance Stage'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
