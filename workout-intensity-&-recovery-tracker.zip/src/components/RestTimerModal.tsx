import React, { useEffect, useState } from 'react';
import { Play, Pause, RotateCcw, Plus, Minus, X, Volume2, VolumeX, CheckCircle2 } from 'lucide-react';
import { playChime } from '../utils/audio';

interface RestTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetSeconds: number;
  exerciseName?: string;
  setNumber?: number;
  onRestCompleted?: (elapsedSeconds: number) => void;
}

export const RestTimerModal: React.FC<RestTimerModalProps> = ({
  isOpen,
  onClose,
  targetSeconds,
  exerciseName,
  setNumber,
  onRestCompleted,
}) => {
  const [totalSeconds, setTotalSeconds] = useState(targetSeconds);
  const [remainingSeconds, setRemainingSeconds] = useState(targetSeconds);
  const [isRunning, setIsRunning] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [elapsedTotal, setElapsedTotal] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setTotalSeconds(targetSeconds);
      setRemainingSeconds(targetSeconds);
      setIsRunning(true);
      setElapsedTotal(0);
    }
  }, [isOpen, targetSeconds]);

  useEffect(() => {
    if (!isOpen || !isRunning) return;

    const interval = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsRunning(false);
          if (soundEnabled) {
            playChime('restEnd');
          }
          return 0;
        }
        if (prev <= 4 && prev > 1 && soundEnabled) {
          playChime('tick');
        }
        return prev - 1;
      });
      setElapsedTotal((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, isRunning, soundEnabled]);

  if (!isOpen) return null;

  const progressPercent = totalSeconds > 0 ? Math.min(100, Math.max(0, ((totalSeconds - remainingSeconds) / totalSeconds) * 100)) : 100;
  const isFinished = remainingSeconds === 0;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleAdjustTime = (delta: number) => {
    setRemainingSeconds((prev) => Math.max(5, prev + delta));
    setTotalSeconds((prev) => Math.max(5, prev + delta));
  };

  const handleReset = () => {
    setRemainingSeconds(targetSeconds);
    setTotalSeconds(targetSeconds);
    setIsRunning(true);
  };

  const handleFinish = () => {
    if (onRestCompleted) {
      onRestCompleted(elapsedTotal);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div
        id="rest-timer-dialog"
        className="w-full max-w-md bg-[#160e22] text-white rounded-2xl border border-[#381f54] shadow-2xl p-6 relative overflow-hidden"
      >
        {/* Top bar */}
        <div className="flex items-center justify-between pb-3 border-b border-[#2d1942]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-pf-yellow animate-pulse"></span>
            <h3 className="font-extrabold text-white text-base">Active Recovery Timer</h3>
          </div>
          <div className="flex items-center gap-1">
            <button
              id="rest-timer-sound-toggle"
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="p-1.5 text-[#a597b4] hover:text-pf-yellow rounded-lg hover:bg-[#25153b] transition-colors"
              title={soundEnabled ? 'Mute sound' : 'Unmute sound'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-pf-yellow" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
            </button>
            <button
              id="rest-timer-close-btn"
              type="button"
              onClick={handleFinish}
              className="p-1.5 text-[#a597b4] hover:text-white rounded-lg hover:bg-[#25153b] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Exercise Context */}
        {exerciseName && (
          <div className="mt-3 py-1.5 px-3 bg-[#1e1130] rounded-lg border border-[#381f54] flex items-center justify-between text-xs text-white font-semibold">
            <span className="truncate">{exerciseName}</span>
            {setNumber && <span className="text-pf-yellow shrink-0 font-bold">Set {setNumber} Complete</span>}
          </div>
        )}

        {/* Circular Display */}
        <div className="my-6 flex flex-col items-center justify-center">
          <div className="relative w-48 h-48 flex items-center justify-center">
            {/* SVG Ring */}
            <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="42"
                className="stroke-[#2c1844] fill-none"
                strokeWidth="8"
              />
              <circle
                cx="50"
                cy="50"
                r="42"
                className={`fill-none transition-all duration-500 ${
                  isFinished ? 'stroke-emerald-400' : 'stroke-pf-yellow'
                }`}
                strokeWidth="8"
                strokeDasharray="263.89"
                strokeDashoffset={263.89 - (263.89 * progressPercent) / 100}
                strokeLinecap="round"
              />
            </svg>

            {/* Center Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              {isFinished ? (
                <div className="flex flex-col items-center animate-bounce text-emerald-400">
                  <CheckCircle2 className="w-10 h-10 mb-1" />
                  <span className="text-sm font-bold uppercase tracking-wider">Rest Complete!</span>
                  <span className="text-xs text-[#a597b4]">Ready for next set</span>
                </div>
              ) : (
                <>
                  <span className="text-4xl font-extrabold tracking-tight text-white font-mono">
                    {formatTime(remainingSeconds)}
                  </span>
                  <span className="text-xs text-pf-yellow mt-1 font-semibold">
                    {isRunning ? 'Recovery Window' : 'Paused'}
                  </span>
                </>
              )}
            </div>
          </div>

          <p className="text-xs text-[#a597b4] text-center max-w-xs mt-2">
            Target protocol rest: 60–90 seconds between sets to restore ATP and maintain high power output.
          </p>
        </div>

        {/* Quick adjustments */}
        <div className="flex items-center justify-center gap-2 mb-5">
          <button
            id="rest-timer-minus-15"
            type="button"
            onClick={() => handleAdjustTime(-15)}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#25153b] hover:bg-[#341d52] border border-[#381f54] rounded-lg transition-colors cursor-pointer"
          >
            <Minus className="w-3 h-3" /> 15s
          </button>
          <button
            id="rest-timer-plus-15"
            type="button"
            onClick={() => handleAdjustTime(15)}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#25153b] hover:bg-[#341d52] border border-[#381f54] rounded-lg transition-colors cursor-pointer"
          >
            <Plus className="w-3 h-3" /> 15s
          </button>
          <button
            id="rest-timer-plus-30"
            type="button"
            onClick={() => handleAdjustTime(30)}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#25153b] hover:bg-[#341d52] border border-[#381f54] rounded-lg transition-colors cursor-pointer"
          >
            <Plus className="w-3 h-3" /> 30s
          </button>
        </div>

        {/* Action Controls */}
        <div className="grid grid-cols-3 gap-2">
          <button
            id="rest-timer-reset-btn"
            type="button"
            onClick={handleReset}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl border border-[#381f54] text-[#a597b4] text-xs font-semibold hover:bg-[#25153b] hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>

          <button
            id="rest-timer-play-pause-btn"
            type="button"
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isRunning
                ? 'bg-amber-500 hover:bg-amber-600 text-white'
                : 'bg-pf-purple hover:bg-pf-purple-light text-white ring-1 ring-pf-yellow/40'
            }`}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current text-pf-yellow" />}
            {isRunning ? 'Pause' : 'Resume'}
          </button>

          <button
            id="rest-timer-next-set-btn"
            type="button"
            onClick={handleFinish}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-pf-purple hover:bg-pf-purple-light text-pf-yellow text-xs font-bold shadow-xs transition-colors cursor-pointer ring-1 ring-pf-yellow/40"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
