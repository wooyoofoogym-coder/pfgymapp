import React, { useState, useEffect } from 'react';
import {
  Music2,
  Play,
  Pause,
  ChevronDown,
  ChevronUp,
  X,
  ExternalLink,
  Plus,
  Flame,
  Dumbbell,
  Sparkles,
  Headphones,
  Check,
  AlertCircle,
  Volume2,
  Radio,
} from 'lucide-react';
import { MusicPreset, MusicProvider } from '../types';
import {
  DEFAULT_MUSIC_PRESETS,
  parseSpotifyUrl,
  parseYouTubeUrl,
} from '../data/musicPresets';

interface MusicPlayerDockProps {
  isOpen: boolean;
  onToggleOpen: () => void;
  // Allows parent views (like Cardio or Spa) to programmatically switch category
  suggestedCategory?: 'cardio' | 'strength' | 'recovery' | 'focus';
}

export const MusicPlayerDock: React.FC<MusicPlayerDockProps> = ({
  isOpen,
  onToggleOpen,
  suggestedCategory,
}) => {
  const [provider, setProvider] = useState<MusicProvider>('spotify');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('spotify-cardio');
  const [isMinimized, setIsMinimized] = useState<boolean>(false);
  const [customInputUrl, setCustomInputUrl] = useState<string>('');
  const [customError, setCustomError] = useState<string | null>(null);
  const [activeCustomTitle, setActiveCustomTitle] = useState<string | null>(null);
  const [embedUrl, setEmbedUrl] = useState<string>(
    DEFAULT_MUSIC_PRESETS[0].embedUrl
  );
  const [currentTrackTitle, setCurrentTrackTitle] = useState<string>(
    DEFAULT_MUSIC_PRESETS[0].title
  );
  const [currentTrackSubtitle, setCurrentTrackSubtitle] = useState<string>(
    DEFAULT_MUSIC_PRESETS[0].subtitle
  );

  // Load saved custom music on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('workout_custom_music');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.embedUrl && parsed.title) {
          setEmbedUrl(parsed.embedUrl);
          setCurrentTrackTitle(parsed.title);
          setCurrentTrackSubtitle(parsed.subtitle || 'Custom User Playlist');
          setProvider(parsed.provider || 'spotify');
          setActiveCustomTitle(parsed.title);
        }
      }
    } catch {}
  }, []);

  // Respond to suggested category change from workout actions
  useEffect(() => {
    if (suggestedCategory) {
      const match = DEFAULT_MUSIC_PRESETS.find(
        (p) => p.category === suggestedCategory && p.provider === provider
      );
      if (match) {
        handleSelectPreset(match);
      }
    }
  }, [suggestedCategory]);

  const handleSelectPreset = (preset: MusicPreset) => {
    setSelectedPresetId(preset.id);
    setProvider(preset.provider);
    setEmbedUrl(preset.embedUrl);
    setCurrentTrackTitle(preset.title);
    setCurrentTrackSubtitle(preset.subtitle);
    setActiveCustomTitle(null);
    setCustomError(null);
  };

  const handleSwitchProvider = (newProvider: MusicProvider) => {
    setProvider(newProvider);
    setCustomError(null);
    const firstMatchingPreset = DEFAULT_MUSIC_PRESETS.find(
      (p) => p.provider === newProvider
    );
    if (firstMatchingPreset) {
      handleSelectPreset(firstMatchingPreset);
    }
  };

  const handleLoadCustomUrl = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!customInputUrl.trim()) return;

    setCustomError(null);

    if (provider === 'spotify') {
      const parsed = parseSpotifyUrl(customInputUrl);
      if (parsed) {
        setEmbedUrl(parsed.embedUrl);
        setCurrentTrackTitle(parsed.title);
        setCurrentTrackSubtitle('Your Personal Spotify Playlist');
        setActiveCustomTitle(parsed.title);
        setSelectedPresetId('custom');

        // Persist to local storage
        localStorage.setItem(
          'workout_custom_music',
          JSON.stringify({
            embedUrl: parsed.embedUrl,
            title: parsed.title,
            subtitle: 'Personal Spotify Playlist',
            provider: 'spotify',
          })
        );
      } else {
        setCustomError(
          'Invalid Spotify URL. Please paste a link like https://open.spotify.com/playlist/... or track URL.'
        );
      }
    } else {
      const parsed = parseYouTubeUrl(customInputUrl);
      if (parsed) {
        setEmbedUrl(parsed.embedUrl);
        setCurrentTrackTitle(parsed.title);
        setCurrentTrackSubtitle('Your Personal YouTube Music');
        setActiveCustomTitle(parsed.title);
        setSelectedPresetId('custom');

        // Persist to local storage
        localStorage.setItem(
          'workout_custom_music',
          JSON.stringify({
            embedUrl: parsed.embedUrl,
            title: parsed.title,
            subtitle: 'Personal YouTube Music',
            provider: 'youtube',
          })
        );
      } else {
        setCustomError(
          'Invalid YouTube link. Please paste a YouTube Music, video, or playlist link.'
        );
      }
    }
  };

  const currentPresets = DEFAULT_MUSIC_PRESETS.filter(
    (p) => p.provider === provider
  );

  // If completely closed, render floating compact launcher pill
  if (!isOpen) {
    return (
      <aside
        aria-label="Workout Music Companion"
        className="fixed bottom-5 right-5 z-40"
      >
        <button
          id="music-launcher-button"
          type="button"
          onClick={onToggleOpen}
          className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#160e22] hover:bg-[#201233] text-white shadow-xl hover:shadow-2xl transition-all duration-200 border border-[#2d1942] group cursor-pointer"
        >
          <div className="relative">
            <Headphones className="w-5 h-5 text-pf-yellow group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-pf-yellow rounded-full animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-pf-yellow rounded-full" />
          </div>
          <div className="text-left pr-1">
            <div className="text-xs font-bold leading-tight flex items-center gap-1.5">
              <span>Music Controls</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#25153b] text-pf-yellow font-mono border border-[#381f54]">
                {provider === 'spotify' ? 'Spotify' : 'YT Music'}
              </span>
            </div>
            <div className="text-[10px] text-[#a597b4] max-w-[130px] truncate">
              {currentTrackTitle}
            </div>
          </div>
        </button>
      </aside>
    );
  }

  // If dock is minimized to bottom bar
  if (isMinimized) {
    return (
      <aside
        aria-label="Minimized Workout Music Bar"
        id="music-player-minimized-bar"
        className="fixed bottom-0 left-0 right-0 z-40 bg-[#140b20] border-t border-[#2d1942] text-white px-4 py-2.5 shadow-2xl flex items-center justify-between gap-4 transition-all"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-[#25153b] flex items-center justify-center shrink-0 border border-[#381f54]">
            {provider === 'spotify' ? (
              <span className="text-emerald-400 font-bold text-sm">🟢</span>
            ) : (
              <span className="text-rose-500 font-bold text-sm">▶️</span>
            )}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold truncate text-white">
                {currentTrackTitle}
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#25153b] text-pf-yellow font-mono shrink-0 border border-[#381f54]">
                {provider === 'spotify' ? 'Spotify' : 'YouTube Music'}
              </span>
            </div>
            <div className="text-[11px] text-[#a597b4] truncate">
              {currentTrackSubtitle}
            </div>
          </div>
        </div>

        {/* Quick category switches */}
        <div className="hidden sm:flex items-center gap-1.5">
          {currentPresets.slice(0, 3).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => handleSelectPreset(p)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedPresetId === p.id && !activeCustomTitle
                  ? 'bg-[#25153b] text-pf-yellow border border-[#381f54]'
                  : 'bg-[#1a0e28] hover:bg-[#201233] text-[#a597b4]'
              }`}
            >
              {p.category === 'cardio' && '🏃 Cardio'}
              {p.category === 'strength' && '🏋️ Lifting'}
              {p.category === 'recovery' && '🧖 Spa / 432Hz'}
            </button>
          ))}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsMinimized(false)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-pf-purple hover:bg-pf-purple-light text-white text-xs font-bold transition-colors cursor-pointer ring-1 ring-pf-yellow/40"
          >
            <ChevronUp className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Open Player</span>
          </button>
          <button
            type="button"
            onClick={onToggleOpen}
            className="p-1.5 text-[#a597b4] hover:text-white rounded-lg hover:bg-[#201233] transition-colors cursor-pointer"
            title="Close Music Player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </aside>
    );
  }

  // Expanded Full Player Modal / Dock Window
  return (
    <aside
      aria-label="Expanded Workout Music Controls"
      id="music-player-expanded-dock"
      className="fixed bottom-3 right-3 sm:bottom-6 sm:right-6 z-50 w-[calc(100vw-24px)] sm:w-[440px] max-h-[92vh] bg-[#160e22] border border-[#2d1942] rounded-2xl shadow-2xl text-white flex flex-col overflow-hidden backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-200"
    >
      {/* Header bar */}
      <div className="p-3.5 bg-[#120a1c] border-b border-[#2d1942] flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#25153b] border border-[#381f54] flex items-center justify-center text-pf-yellow">
            <Music2 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white flex items-center gap-2">
              <span>Workout & Recovery Audio</span>
              <span className="inline-block w-2 h-2 rounded-full bg-pf-yellow animate-pulse" />
            </h3>
            <p className="text-[10px] text-[#a597b4]">
              In-session Spotify & YouTube Music controls
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setIsMinimized(true)}
            className="p-1.5 text-[#a597b4] hover:text-white hover:bg-[#201233] rounded-lg transition-colors cursor-pointer"
            title="Minimize to bottom bar"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onToggleOpen}
            className="p-1.5 text-[#a597b4] hover:text-white hover:bg-[#201233] rounded-lg transition-colors cursor-pointer"
            title="Close player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Provider Selector: Spotify vs YouTube Music */}
      <div className="p-3 bg-[#160e22] border-b border-[#2d1942] flex items-center gap-2">
        <button
          id="music-provider-spotify"
          type="button"
          onClick={() => handleSwitchProvider('spotify')}
          className={`flex-1 flex items-center justify-center gap-2 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            provider === 'spotify'
              ? 'bg-[#1DB954] text-black shadow-sm font-extrabold'
              : 'bg-[#1a0e28] text-[#a597b4] hover:bg-[#201233] hover:text-white border border-[#2d1942]'
          }`}
        >
          <span className="text-sm">🟢</span>
          <span>Spotify</span>
        </button>

        <button
          id="music-provider-youtube"
          type="button"
          onClick={() => handleSwitchProvider('youtube')}
          className={`flex-1 flex items-center justify-center gap-2 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            provider === 'youtube'
              ? 'bg-[#FF0000] text-white shadow-sm font-extrabold'
              : 'bg-[#1a0e28] text-[#a597b4] hover:bg-[#201233] hover:text-white border border-[#2d1942]'
          }`}
        >
          <span className="text-sm">▶️</span>
          <span>YouTube Music</span>
        </button>
      </div>

      {/* Scrollable Body: Embedded Player & Presets */}
      <div className="p-4 space-y-4 overflow-y-auto max-h-[calc(92vh-180px)] scrollbar-thin scrollbar-thumb-[#2d1942]">
        {/* Active Embedded Player */}
        <div className="rounded-xl overflow-hidden bg-[#0f0716] border border-[#2d1942] shadow-inner">
          <div className="p-2.5 bg-[#120a1c] border-b border-[#2d1942] flex items-center justify-between text-xs">
            <div className="min-w-0 pr-2">
              <div className="font-bold text-white truncate">
                {currentTrackTitle}
              </div>
              <div className="text-[10px] text-[#a597b4] truncate">
                {currentTrackSubtitle}
              </div>
            </div>

            <a
              href={
                provider === 'spotify'
                  ? 'https://open.spotify.com'
                  : 'https://music.youtube.com'
              }
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-[10px] text-[#a597b4] hover:text-white px-2 py-1 rounded bg-[#1a0e28] hover:bg-[#201233] border border-[#2d1942] transition-colors shrink-0"
              title="Open full app in new tab"
            >
              <span>Open App</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {/* Real Interactive Embed Iframe with Native Playback Controls */}
          <div className="w-full relative flex items-center justify-center bg-black">
            {provider === 'spotify' ? (
              <iframe
                id="spotify-embed-frame"
                src={embedUrl}
                width="100%"
                height="152"
                frameBorder="0"
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                loading="lazy"
                title="Spotify Workout Player"
                className="w-full rounded-b-xl"
              />
            ) : (
              <iframe
                id="youtube-embed-frame"
                src={embedUrl}
                width="100%"
                height="200"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title="YouTube Workout Player"
                className="w-full rounded-b-xl"
              />
            )}
          </div>
        </div>

        {/* Custom Playlist / Track Link Loader */}
        <div className="bg-[#1a0e28] rounded-xl p-3 border border-[#2d1942] space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Load My {provider === 'spotify' ? 'Spotify' : 'YouTube Music'} Link</span>
            </label>
            <span className="text-[10px] text-[#a597b4]">Playlists, albums & songs</span>
          </div>

          <form onSubmit={handleLoadCustomUrl} className="flex gap-2">
            <input
              id="custom-music-url-input"
              type="text"
              value={customInputUrl}
              onChange={(e) => setCustomInputUrl(e.target.value)}
              placeholder={
                provider === 'spotify'
                  ? 'Paste Spotify playlist or song link...'
                  : 'Paste YouTube / YouTube Music link...'
              }
              className="flex-1 text-xs bg-[#140b20] border border-[#381f54] rounded-lg px-3 py-2 text-white placeholder:text-[#8e7e9f] focus:outline-hidden focus:border-pf-yellow"
            />
            <button
              id="apply-custom-music-button"
              type="submit"
              className="px-3 py-2 rounded-lg bg-pf-purple hover:bg-pf-purple-light text-white font-bold text-xs flex items-center gap-1 transition-colors cursor-pointer shrink-0 ring-1 ring-pf-yellow/40"
            >
              <Play className="w-3 h-3 fill-current text-pf-yellow" />
              <span>Load</span>
            </button>
          </form>

          {customError && (
            <div className="flex items-start gap-1.5 text-[11px] text-rose-400 mt-1">
              <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>{customError}</span>
            </div>
          )}

          {activeCustomTitle && (
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-300 bg-[#0f241d] border border-emerald-800 p-2 rounded-lg">
              <Check className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
              <span>Loaded custom link: <strong>{activeCustomTitle}</strong></span>
            </div>
          )}
        </div>

        {/* Curated Workout & Recovery Soundscapes */}
        <div className="space-y-2">
          <div className="text-xs font-bold text-[#a597b4] uppercase tracking-wider flex items-center justify-between">
            <span>Curated Protocol Soundscapes</span>
            <span className="text-[10px] text-[#8e7e9f] font-normal">One-tap switch</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {currentPresets.map((preset) => {
              const isSelected = selectedPresetId === preset.id && !activeCustomTitle;
              return (
                <button
                  key={preset.id}
                  id={`preset-${preset.id}`}
                  type="button"
                  onClick={() => handleSelectPreset(preset)}
                  className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
                    isSelected
                      ? 'bg-[#25153b] border-pf-purple shadow-xs ring-1 ring-pf-yellow/40 text-white'
                      : 'bg-[#1a0e28] border-[#2d1942] hover:bg-[#201233] text-[#d0c2df]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      {preset.category === 'cardio' && <Flame className="w-3.5 h-3.5 text-pf-yellow" />}
                      {preset.category === 'strength' && <Dumbbell className="w-3.5 h-3.5 text-purple-400" />}
                      {preset.category === 'recovery' && <Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
                      {preset.category === 'focus' && <Headphones className="w-3.5 h-3.5 text-sky-400" />}
                      <span className="truncate">{preset.name}</span>
                    </div>

                    {isSelected && (
                      <span className="w-2 h-2 rounded-full bg-pf-yellow shrink-0" />
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-[#8e7e9f] truncate">{preset.title}</span>
                    <span className="font-semibold text-pf-yellow font-mono shrink-0 ml-1">
                      {preset.bpmOrVibe}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick Connection Tip */}
        <div className="p-3 rounded-xl bg-[#120a1c] border border-[#2d1942] text-[11px] text-[#a597b4] flex items-start gap-2">
          <Volume2 className="w-4 h-4 text-pf-yellow shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Pro Tip:</strong> Log in to your {provider === 'spotify' ? 'Spotify' : 'YouTube'} account in another tab on this browser to unlock full-length tracks, personal playlists, and premium ad-free streaming directly inside these controls.
          </p>
        </div>
      </div>
    </aside>
  );
};
