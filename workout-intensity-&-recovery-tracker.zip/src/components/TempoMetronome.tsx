import React, { useState, useEffect, useRef } from 'react';
import { Play, Square, Volume2, VolumeX, Activity } from 'lucide-react';
import { playChime } from '../utils/audio';

export const TempoMetronome: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<'out' | 'back'>('out'); // 2s out / 2s back
  const [count, setCount] = useState(1);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!isActive) {
      setPhase('out');
      setCount(1);
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setCount((prev) => {
        if (soundEnabled) {
          playChime('tick');
        }
        if (prev === 1) {
          return 2;
        } else {
          // Flip phase
          setPhase((p) => (p === 'out' ? 'back' : 'out'));
          return 1;
        }
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, soundEnabled]);

  return (
    <div
      id="tempo-metronome-card"
      className="p-3.5 bg-pf-purple-deep text-white rounded-xl border border-pf-purple-border shadow-md flex flex-col sm:flex-row items-center justify-between gap-3"
    >
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-pf-purple-surface text-pf-yellow flex items-center justify-center shrink-0">
          <Activity className="w-4 h-4" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200">Tempo Guide</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-pf-yellow text-pf-purple-deep font-black shadow-2xs">
              2s Out / 2s Back
            </span>
          </div>
          <p className="text-xs text-slate-300">
            {isActive
              ? phase === 'out'
                ? 'Push / Pull Outward (Concentric)'
                : 'Controlled Return Back (Eccentric)'
              : 'Controlled tempo maximizes muscle tension & safety'}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Visual Pulse Indicator */}
        {isActive && (
          <div className="flex items-center gap-2 px-3 py-1 bg-pf-purple-dark rounded-lg border border-pf-purple-border">
            <span
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                phase === 'out' ? 'bg-pf-yellow scale-110 shadow-pf-yellow/50 shadow-md' : 'bg-emerald-400 scale-110 shadow-emerald-500/50 shadow-md'
              }`}
            />
            <span className="text-xs font-mono font-bold uppercase w-14 text-center">
              {phase} {count}s
            </span>
          </div>
        )}

        {/* Audio Toggle */}
        <button
          id="tempo-sound-toggle"
          type="button"
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`p-2 rounded-lg text-xs transition-colors cursor-pointer ${
            soundEnabled ? 'text-pf-yellow bg-pf-purple border border-pf-purple-border' : 'text-slate-400 hover:text-slate-200 bg-pf-purple-dark'
          }`}
          title={soundEnabled ? 'Audio tick enabled' : 'Audio tick muted'}
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>

        {/* Start / Stop Toggle */}
        <button
          id="tempo-toggle-btn"
          type="button"
          onClick={() => setIsActive(!isActive)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            isActive ? 'bg-rose-600 hover:bg-rose-700 text-white' : 'bg-pf-yellow hover:bg-pf-yellow-hover text-pf-purple-deep shadow-2xs'
          }`}
        >
          {isActive ? <Square className="w-3 h-3 fill-current" /> : <Play className="w-3 h-3 fill-current" />}
          {isActive ? 'Stop Tempo' : 'Start Metronome'}
        </button>
      </div>
    </div>
  );
};
