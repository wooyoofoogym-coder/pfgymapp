import {
  CustomGoals,
  ProgressiveOverloadSuggestion,
  ReadinessCheck,
  TreadmillOverloadSuggestion,
  WorkoutSession,
} from '../types';
import { DEFAULT_EXERCISES, TREADMILL_TIERS } from '../data/protocolDefaults';

/**
 * Calculates pre-workout recovery readiness score based on sleep quality (1-5),
 * energy level (1-5), and muscular soreness (1-5, where 1 = no soreness, 5 = severe soreness).
 */
export function calculateReadinessScore(
  sleepQuality: number,
  energyLevel: number,
  muscleSoreness: number
): ReadinessCheck {
  // Normalize factors (sleep 1-5 -> 0-1, energy 1-5 -> 0-1, soreness reversed 1-5 -> 1-0)
  const sleepNorm = (sleepQuality - 1) / 4;
  const energyNorm = (energyLevel - 1) / 4;
  const sorenessInvertedNorm = (5 - muscleSoreness) / 4;

  // Weighted score: 35% sleep, 35% energy, 30% low soreness
  const rawScore = sleepNorm * 35 + energyNorm * 35 + sorenessInvertedNorm * 30;
  const score = Math.max(10, Math.min(100, Math.round(rawScore)));

  let status: 'optimal' | 'moderate' | 'fatigued' = 'moderate';
  let recommendedRestSeconds = 75;

  if (score >= 80) {
    status = 'optimal';
    recommendedRestSeconds = 60; // crisp standard rest
  } else if (score >= 55) {
    status = 'moderate';
    recommendedRestSeconds = 75; // protocol baseline
  } else {
    status = 'fatigued';
    recommendedRestSeconds = 90; // extended recovery to protect joint integrity
  }

  return {
    sleepQuality,
    energyLevel,
    muscleSoreness,
    readinessScore: score,
    status,
    recommendedRestSeconds,
    date: new Date().toISOString(),
  };
}

/**
 * Calculates total volume (tonnage) lifted in lbs across all completed sets
 */
export function calculateSessionVolume(session: WorkoutSession): number {
  if (!session.exercises) return 0;
  return session.exercises.reduce((total, ex) => {
    const exVol = ex.sets.reduce((sum, s) => {
      if (s.completed) {
        return sum + s.weightLbs * s.actualReps;
      }
      return sum;
    }, 0);
    return total + exVol;
  }, 0);
}

/**
 * Evaluates past workouts and detects if progressive overload should be recommended.
 * Rule: If user completed target sets & reps on an exercise with average RPE <= 6 (Target Zone),
 * recommend +5 lbs (or +10 lbs for Leg Press).
 */
export function detectProgressiveOverload(
  workouts: WorkoutSession[],
  customGoals: CustomGoals
): {
  exerciseSuggestions: ProgressiveOverloadSuggestion[];
  treadmillSuggestion: TreadmillOverloadSuggestion | null;
} {
  const exerciseSuggestions: ProgressiveOverloadSuggestion[] = [];
  let treadmillSuggestion: TreadmillOverloadSuggestion | null = null;

  if (!workouts || workouts.length === 0) {
    return { exerciseSuggestions, treadmillSuggestion };
  }

  const latestWorkout = workouts[0];

  // Analyze Resistance Machines
  DEFAULT_EXERCISES.forEach((def) => {
    const loggedEx = latestWorkout.exercises?.find((e) => e.exerciseId === def.id);
    if (!loggedEx || !loggedEx.sets || loggedEx.sets.length === 0) return;

    const completedSets = loggedEx.sets.filter((s) => s.completed);
    if (completedSets.length === 0) return;

    // Check if user finished all target sets
    const targetGoal = customGoals.exerciseTargets[def.id] || {
      targetWeightLbs: def.defaultWeight,
      targetReps: 12,
      targetSets: def.defaultSets,
    };

    const finishedAllSets = completedSets.length >= targetGoal.targetSets;
    const avgRpe =
      completedSets.reduce((sum, s) => sum + s.rpe, 0) / completedSets.length;
    const currentWeight = completedSets[0].weightLbs || targetGoal.targetWeightLbs;

    // If completed all sets and RPE <= 6 (meaning within or easier than target zone limit)
    if (finishedAllSets && avgRpe <= 6.0) {
      const stepLbs = def.id === 'leg_press' ? 10 : 5;
      const suggestedWeight = currentWeight + stepLbs;

      exerciseSuggestions.push({
        exerciseId: def.id,
        exerciseName: def.name,
        currentWeightLbs: currentWeight,
        suggestedWeightLbs: suggestedWeight,
        increaseLbs: stepLbs,
        reason: `Completed ${completedSets.length}/${targetGoal.targetSets} sets @ ${currentWeight} lbs with sustainable intensity (Avg RPE ${avgRpe.toFixed(1)}). Ready for +${stepLbs} lbs overload.`,
      });
    }
  });

  // Analyze Treadmill Progression
  const cardio = latestWorkout.cardio;
  if (cardio && cardio.actualDurationMinutes >= 15 && cardio.actualRpe <= 6) {
    const currentTier = customGoals.progressionTier;
    if (currentTier === 'weeks_1_2') {
      treadmillSuggestion = {
        currentTier: 'weeks_1_2',
        suggestedTier: 'weeks_3_4',
        suggestedIncline: 6.0,
        suggestedSpeed: 2.2,
        reason: `Completed baseline incline with manageable exertion (RPE ${cardio.actualRpe}). Progress to Weeks 3–4 (6.0% Incline @ 2.0–2.3 mph).`,
      };
    } else if (currentTier === 'weeks_3_4') {
      treadmillSuggestion = {
        currentTier: 'weeks_3_4',
        suggestedTier: 'weeks_5_6_plus',
        suggestedIncline: 10.0,
        suggestedSpeed: 1.9,
        reason: `Mastered intermediate incline. Progress to Weeks 5–6+ (10.0%–12.0%+ Incline @ 1.8–2.0 mph).`,
      };
    }
  }

  return { exerciseSuggestions, treadmillSuggestion };
}
