import { CustomGoals, SpaSession, WorkoutSession } from '../types';
import { DEFAULT_CUSTOM_GOALS } from '../data/protocolDefaults';

const STORAGE_KEYS = {
  GOALS: 'fitness_custom_goals_v1',
  WORKOUTS: 'fitness_workout_history_v1',
  SPA_SESSIONS: 'fitness_spa_history_v1',
  HYDRATION: 'fitness_hydration_v1',
  ACTIVE_DRAFT: 'fitness_active_draft_v1',
};

// Seed sample historical sessions so the intensity and recovery charts are immediately illustrative
const SEED_WORKOUTS: WorkoutSession[] = [
  {
    id: 'seed-1',
    date: new Date(Date.now() - 4 * 86400000).toISOString(),
    totalDurationMinutes: 52,
    preWorkoutPrepMinutes: 12,
    prepCompleted: true,
    prepLevel: 1,
    cardio: {
      inclinePercent: 4.0,
      speedMph: 2.2,
      targetDurationMinutes: 15,
      actualDurationMinutes: 16,
      targetRpe: 'RPE 4–6',
      actualRpe: 5,
      coolDownCompleted: true,
      notes: 'Maintained steady cadence without touching handrails',
    },
    exercises: [
      {
        exerciseId: 'chest_press',
        name: 'Seated Chest Press',
        keyFocus: 'Upper body support & posture',
        sets: [
          { id: 's1', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 45, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's2', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 50, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's3', setNumber: 3, targetReps: '10–12', actualReps: 10, weightLbs: 50, rpe: 6, completed: true, restDurationSeconds: 80 },
        ],
      },
      {
        exerciseId: 'lat_pulldown',
        name: 'Seated Lat Pulldown',
        keyFocus: 'Pull down to upper chest',
        sets: [
          { id: 's4', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 60, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's5', setNumber: 2, targetReps: '10–12', actualReps: 11, weightLbs: 60, rpe: 6, completed: true, restDurationSeconds: 75 },
          { id: 's6', setNumber: 3, targetReps: '10–12', actualReps: 10, weightLbs: 65, rpe: 6, completed: true, restDurationSeconds: 85 },
        ],
      },
      {
        exerciseId: 'leg_press',
        name: 'Seated Leg Press',
        keyFocus: 'Wide feet placement; no lockouts',
        sets: [
          { id: 's7', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 100, rpe: 5, completed: true, restDurationSeconds: 90 },
          { id: 's8', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 110, rpe: 5, completed: true, restDurationSeconds: 90 },
          { id: 's9', setNumber: 3, targetReps: '10–12', actualReps: 12, weightLbs: 110, rpe: 6, completed: true, restDurationSeconds: 90 },
        ],
      },
      {
        exerciseId: 'cable_row',
        name: 'Seated Cable Row',
        keyFocus: 'Mid-back contraction & tall posture',
        sets: [
          { id: 's10', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 55, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's11', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 55, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's12', setNumber: 3, targetReps: '10–12', actualReps: 11, weightLbs: 55, rpe: 6, completed: true, restDurationSeconds: 75 },
        ],
      },
      {
        exerciseId: 'ab_crunch',
        name: 'Ab Crunch Machine',
        keyFocus: 'Controlled core pull',
        sets: [
          { id: 's13', setNumber: 1, targetReps: '12–15', actualReps: 15, weightLbs: 35, rpe: 5, completed: true, restDurationSeconds: 60 },
          { id: 's14', setNumber: 2, targetReps: '12–15', actualReps: 14, weightLbs: 40, rpe: 6, completed: true, restDurationSeconds: 60 },
        ],
      },
    ],
    postWorkoutHydroMinutes: 10,
    postWorkoutCompleted: true,
    totalRestRecoverySeconds: 1085, // ~18 mins in-circuit rest
    averageRpe: 5.4,
    notes: 'Hit the target RPE 4-6 zone consistently. Felt energized after post-workout hydromassage.',
  },
  {
    id: 'seed-2',
    date: new Date(Date.now() - 2 * 86400000).toISOString(),
    totalDurationMinutes: 55,
    preWorkoutPrepMinutes: 12,
    prepCompleted: true,
    prepLevel: 2,
    cardio: {
      inclinePercent: 4.5,
      speedMph: 2.3,
      targetDurationMinutes: 18,
      actualDurationMinutes: 18,
      targetRpe: 'RPE 4–6',
      actualRpe: 6,
      coolDownCompleted: true,
      notes: 'Solid incline progression, 2-min 0% incline cool down completed.',
    },
    exercises: [
      {
        exerciseId: 'chest_press',
        name: 'Seated Chest Press',
        keyFocus: 'Upper body support & posture',
        sets: [
          { id: 's21', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 50, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's22', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 50, rpe: 6, completed: true, restDurationSeconds: 75 },
          { id: 's23', setNumber: 3, targetReps: '10–12', actualReps: 11, weightLbs: 55, rpe: 6, completed: true, restDurationSeconds: 80 },
        ],
      },
      {
        exerciseId: 'lat_pulldown',
        name: 'Seated Lat Pulldown',
        keyFocus: 'Pull down to upper chest',
        sets: [
          { id: 's24', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 60, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's25', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 65, rpe: 6, completed: true, restDurationSeconds: 80 },
          { id: 's26', setNumber: 3, targetReps: '10–12', actualReps: 10, weightLbs: 65, rpe: 6, completed: true, restDurationSeconds: 85 },
        ],
      },
      {
        exerciseId: 'leg_press',
        name: 'Seated Leg Press',
        keyFocus: 'Wide feet placement; no lockouts',
        sets: [
          { id: 's27', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 110, rpe: 5, completed: true, restDurationSeconds: 90 },
          { id: 's28', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 115, rpe: 6, completed: true, restDurationSeconds: 90 },
          { id: 's29', setNumber: 3, targetReps: '10–12', actualReps: 12, weightLbs: 115, rpe: 6, completed: true, restDurationSeconds: 90 },
        ],
      },
      {
        exerciseId: 'cable_row',
        name: 'Seated Cable Row',
        keyFocus: 'Mid-back contraction & tall posture',
        sets: [
          { id: 's30', setNumber: 1, targetReps: '10–12', actualReps: 12, weightLbs: 55, rpe: 5, completed: true, restDurationSeconds: 75 },
          { id: 's31', setNumber: 2, targetReps: '10–12', actualReps: 12, weightLbs: 60, rpe: 6, completed: true, restDurationSeconds: 75 },
          { id: 's32', setNumber: 3, targetReps: '10–12', actualReps: 11, weightLbs: 60, rpe: 6, completed: true, restDurationSeconds: 75 },
        ],
      },
      {
        exerciseId: 'ab_crunch',
        name: 'Ab Crunch Machine',
        keyFocus: 'Controlled core pull',
        sets: [
          { id: 's33', setNumber: 1, targetReps: '12–15', actualReps: 15, weightLbs: 40, rpe: 5, completed: true, restDurationSeconds: 60 },
          { id: 's34', setNumber: 2, targetReps: '12–15', actualReps: 15, weightLbs: 40, rpe: 6, completed: true, restDurationSeconds: 60 },
        ],
      },
    ],
    postWorkoutHydroMinutes: 10,
    postWorkoutCompleted: true,
    totalRestRecoverySeconds: 1110,
    averageRpe: 5.7,
    notes: 'Progressed weights on Chest Press and Leg Press with steady 2s/2s tempo.',
  },
];

const SEED_SPA: SpaSession[] = [
  {
    id: 'spa-seed-1',
    date: new Date(Date.now() - 3 * 86400000).toISOString(),
    amenities: [
      { amenityId: 'dry_plunge', name: 'Polar Dry Plunge', durationMinutes: 4, completed: true },
      { amenityId: 'total_body_enhancer', name: 'Total Body Enhancer', durationMinutes: 12, completed: true },
      { amenityId: 'hydromassage', name: 'HydroMassage Bed', durationMinutes: 10, completed: true },
      { amenityId: 'spray_tan', name: 'Spray Tan Booth', durationMinutes: 4, completed: true },
    ],
    totalDurationMinutes: 30,
    notes: 'Full dedicated recovery day circuit. Legs feel fresh and relaxed.',
  },
];

export function getCustomGoals(): CustomGoals {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GOALS);
    if (!raw) return DEFAULT_CUSTOM_GOALS;
    return { ...DEFAULT_CUSTOM_GOALS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CUSTOM_GOALS;
  }
}

export function saveCustomGoals(goals: CustomGoals): void {
  try {
    localStorage.setItem(STORAGE_KEYS.GOALS, JSON.stringify(goals));
  } catch (err) {
    console.error('Failed to save custom goals', err);
  }
}

export function getWorkoutsHistory(): WorkoutSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WORKOUTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(SEED_WORKOUTS));
      return SEED_WORKOUTS;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_WORKOUTS;
  }
}

export function saveWorkoutSession(session: WorkoutSession): WorkoutSession[] {
  try {
    const existing = getWorkoutsHistory();
    const updated = [session, ...existing.filter((s) => s.id !== session.id)];
    localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(updated));
    return updated;
  } catch {
    return getWorkoutsHistory();
  }
}

export function deleteWorkoutSession(id: string): WorkoutSession[] {
  try {
    const existing = getWorkoutsHistory();
    const updated = existing.filter((s) => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.WORKOUTS, JSON.stringify(updated));
    return updated;
  } catch {
    return getWorkoutsHistory();
  }
}

export function getSpaHistory(): SpaSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SPA_SESSIONS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SPA_SESSIONS, JSON.stringify(SEED_SPA));
      return SEED_SPA;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_SPA;
  }
}

export function saveSpaSession(session: SpaSession): SpaSession[] {
  try {
    const existing = getSpaHistory();
    const updated = [session, ...existing.filter((s) => s.id !== session.id)];
    localStorage.setItem(STORAGE_KEYS.SPA_SESSIONS, JSON.stringify(updated));
    return updated;
  } catch {
    return getSpaHistory();
  }
}

export function getHydrationToday(): { date: string; ounces: number } {
  try {
    const todayStr = new Date().toISOString().split('T')[0];
    const raw = localStorage.getItem(STORAGE_KEYS.HYDRATION);
    if (!raw) return { date: todayStr, ounces: 24 };
    const parsed = JSON.parse(raw);
    if (parsed.date !== todayStr) {
      return { date: todayStr, ounces: 0 };
    }
    return parsed;
  } catch {
    return { date: new Date().toISOString().split('T')[0], ounces: 24 };
  }
}

export function saveHydrationToday(ounces: number): void {
  try {
    const todayStr = new Date().toISOString().split('T')[0];
    localStorage.setItem(STORAGE_KEYS.HYDRATION, JSON.stringify({ date: todayStr, ounces }));
  } catch {}
}
