import { MusicPreset, MusicProvider } from '../types';

export const DEFAULT_MUSIC_PRESETS: MusicPreset[] = [
  // Spotify Presets
  {
    id: 'spotify-cardio',
    name: 'Cardio Incline Drive',
    category: 'cardio',
    provider: 'spotify',
    title: 'Beast Mode Cardio',
    subtitle: 'High-cadence 130–145 BPM driving rhythm for treadmill intervals',
    embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX76Wlfdnj7AP?utm_source=generator&theme=0',
    bpmOrVibe: '135–145 BPM',
  },
  {
    id: 'spotify-strength',
    name: 'Heavy Resistance Power',
    category: 'strength',
    provider: 'spotify',
    title: 'Power Workout & Bass',
    subtitle: 'Aggressive heavy-tempo bassline for machine resistance sets',
    embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DXdxcBWuJwBLq?utm_source=generator&theme=0',
    bpmOrVibe: 'High Intensity Bass',
  },
  {
    id: 'spotify-recovery',
    name: 'Rest Day Spa & Recovery',
    category: 'recovery',
    provider: 'spotify',
    title: 'Restorative Spa Soundscape',
    subtitle: 'Passive ambient frequencies for HydroMassage & post-circuit calm',
    embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DX3Ogo9pFvBkY?utm_source=generator&theme=0',
    bpmOrVibe: '432Hz Calming Ambient',
  },
  {
    id: 'spotify-focus',
    name: 'Lo-Fi Focus & Mobility',
    category: 'focus',
    provider: 'spotify',
    title: 'Lo-Fi Beats for Prep & Stretch',
    subtitle: 'Subtle rhythm for warm-up and active recovery intervals',
    embedUrl: 'https://open.spotify.com/embed/playlist/37i9dQZF1DXdLEN7aqioXM?utm_source=generator&theme=0',
    bpmOrVibe: 'Smooth Lo-Fi Chill',
  },

  // YouTube / YouTube Music Presets
  {
    id: 'yt-cardio',
    name: 'High-Tempo Synthwave Sprint',
    category: 'cardio',
    provider: 'youtube',
    title: 'Retro Wave Cardio Pump',
    subtitle: 'Steady electronic propulsion for treadmill progression',
    embedUrl: 'https://www.youtube.com/embed/videoseries?list=PL_J8l1K0L4Q8iJ9Jd1hU3m0u4zE_N4P-1',
    bpmOrVibe: '138 BPM Synthwave',
  },
  {
    id: 'yt-strength',
    name: 'Phonk & Heavy Gym Drive',
    category: 'strength',
    provider: 'youtube',
    title: 'Heavy Lifting Beats',
    subtitle: 'Aggressive focus music for high-effort resistance circuits',
    embedUrl: 'https://www.youtube.com/embed/videoseries?list=PLx0sYbCqOb8TBPRdmBHs5Iftvv9TPboYG',
    bpmOrVibe: 'Heavy Phonk & Bass',
  },
  {
    id: 'yt-recovery',
    name: '432Hz Deep Muscular Recovery',
    category: 'recovery',
    provider: 'youtube',
    title: 'Cellular Restoration & Spa Plunge',
    subtitle: 'Calming delta soundscape for thermal therapy & HydroMassage',
    embedUrl: 'https://www.youtube.com/embed/lTRiuFIWV54?enablejsapi=1',
    bpmOrVibe: '432Hz Spa Frequency',
  },
  {
    id: 'yt-focus',
    name: 'Chillhop Rest Day Live',
    category: 'focus',
    provider: 'youtube',
    title: 'Lofi Girl Relax & Recovery',
    subtitle: 'Continuous soothing beats for between-set cooldowns',
    embedUrl: 'https://www.youtube.com/embed/jfKfPfyJRdk?enablejsapi=1',
    bpmOrVibe: 'Warm Lo-Fi Stream',
  },
];

/**
 * Parses user-provided Spotify URL and converts into an embed URL
 * Supports:
 * - https://open.spotify.com/playlist/...
 * - https://open.spotify.com/album/...
 * - https://open.spotify.com/track/...
 * - spotify:playlist:...
 */
export function parseSpotifyUrl(input: string): { embedUrl: string; title: string } | null {
  if (!input || typeof input !== 'string') return null;
  const trimmed = input.trim();

  // URL format: open.spotify.com/(playlist|track|album|artist|show|episode)/([a-zA-Z0-9]+)
  const urlMatch = trimmed.match(/open\.spotify\.com\/(playlist|track|album|artist|show|episode)\/([a-zA-Z0-9]+)/i);
  if (urlMatch) {
    const type = urlMatch[1];
    const id = urlMatch[2];
    const capitalized = type.charAt(0).toUpperCase() + type.slice(1);
    return {
      embedUrl: `https://open.spotify.com/embed/${type}/${id}?utm_source=generator&theme=0`,
      title: `My Spotify ${capitalized}`,
    };
  }

  // URI format: spotify:(playlist|track|album):([a-zA-Z0-9]+)
  const uriMatch = trimmed.match(/spotify:(playlist|track|album|artist):([a-zA-Z0-9]+)/i);
  if (uriMatch) {
    const type = uriMatch[1];
    const id = uriMatch[2];
    const capitalized = type.charAt(0).toUpperCase() + type.slice(1);
    return {
      embedUrl: `https://open.spotify.com/embed/${type}/${id}?utm_source=generator&theme=0`,
      title: `My Spotify ${capitalized}`,
    };
  }

  // If user pasted embed code
  const iframeMatch = trimmed.match(/src=["'](https:\/\/open\.spotify\.com\/embed\/[^"']+)["']/i);
  if (iframeMatch) {
    return {
      embedUrl: iframeMatch[1],
      title: 'Custom Spotify Embed',
    };
  }

  return null;
}

/**
 * Parses user-provided YouTube / YouTube Music URL into an embed URL
 * Supports:
 * - music.youtube.com/watch?v=...
 * - youtube.com/watch?v=...
 * - youtu.be/...
 * - youtube.com/playlist?list=...
 */
export function parseYouTubeUrl(input: string): { embedUrl: string; title: string } | null {
  if (!input || typeof input !== 'string') return null;
  const trimmed = input.trim();

  // Check for playlist list=...
  const playlistMatch = trimmed.match(/[?&]list=([a-zA-Z0-9_-]+)/i);
  if (playlistMatch) {
    const listId = playlistMatch[1];
    return {
      embedUrl: `https://www.youtube.com/embed/videoseries?list=${listId}&enablejsapi=1`,
      title: 'My YouTube Playlist',
    };
  }

  // Check for standard watch?v=...
  const videoMatch = trimmed.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|music\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/i);
  if (videoMatch) {
    const videoId = videoMatch[1];
    return {
      embedUrl: `https://www.youtube.com/embed/${videoId}?enablejsapi=1`,
      title: 'My YouTube Music Track',
    };
  }

  // Check for youtu.be/ID
  const shortMatch = trimmed.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/i);
  if (shortMatch) {
    const videoId = shortMatch[1];
    return {
      embedUrl: `https://www.youtube.com/embed/${videoId}?enablejsapi=1`,
      title: 'My YouTube Music Track',
    };
  }

  // If user pasted embed code
  const iframeMatch = trimmed.match(/src=["'](https:\/\/www\.youtube\.com\/embed\/[^"']+)["']/i);
  if (iframeMatch) {
    return {
      embedUrl: iframeMatch[1],
      title: 'Custom YouTube Embed',
    };
  }

  return null;
}
